// Runs before first paint (loaded in <head>) so there is no light/dark flash.
(function () {
  try {
    var t = localStorage.getItem('bw-theme');
    if (t === 'dark' || t === 'light') { document.documentElement.setAttribute('data-theme', t); }
  } catch (e) { /* storage blocked – fall back to system preference */ }
})();

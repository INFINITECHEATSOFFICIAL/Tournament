(function () {
  'use strict';
  var d = document;

  // Mobile sidebar
  d.addEventListener('click', function (e) {
    if (e.target.closest('[data-nav-toggle]')) { d.body.classList.toggle('nav-open'); }
    else if (e.target.closest('[data-nav-close]')) { d.body.classList.remove('nav-open'); }

    var dismiss = e.target.closest('[data-dismiss]');
    if (dismiss) { dismiss.parentElement.remove(); }

    // Theme toggle
    if (e.target.closest('[data-theme-toggle]')) {
      var root = d.documentElement;
      var current = root.getAttribute('data-theme') ||
        (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
      var next = current === 'dark' ? 'light' : 'dark';
      root.setAttribute('data-theme', next);
      try { localStorage.setItem('bw-theme', next); } catch (err) { /* ignore */ }
    }
  });

  // Confirm dialogs: <form data-confirm="…"> or <button data-confirm="…">
  d.addEventListener('submit', function (e) {
    var msg = (e.submitter && e.submitter.dataset.confirm) || e.target.dataset.confirm;
    if (msg && !window.confirm(msg)) { e.preventDefault(); }
  });

  // Selects that submit their form on change
  d.addEventListener('change', function (e) {
    if (e.target.matches('[data-autosubmit]') && e.target.form) { e.target.form.submit(); }
  });

  // Prevent double submits
  d.addEventListener('submit', function (e) {
    if (e.defaultPrevented) { return; }
    var btns = e.target.querySelectorAll('button[type=submit], button:not([type])');
    setTimeout(function () { btns.forEach(function (b) { b.disabled = true; }); }, 0);
  });
  window.addEventListener('pageshow', function () {
    d.querySelectorAll('button[disabled]').forEach(function (b) { b.disabled = false; });
  });

  // Match form: free matches have no entry fee
  var type = d.getElementById('matchtype');
  var fee = d.getElementById('entryfee');
  if (type && fee) {
    var sync = function () {
      var free = type.value === 'Free';
      fee.disabled = free;
      if (free) { fee.value = 0; }
    };
    type.addEventListener('change', sync);
    sync();
  }

  // Score form: auto-calculate winnings = kills × per-kill (+ winner prize for rank 1)
  var form = d.getElementById('score-form');
  if (form) {
    var perKill = parseInt(form.dataset.perkill, 10) || 0;
    var winPrize = parseInt(form.dataset.winprice, 10) || 0;
    var btn = form.querySelector('[data-autocalc]');
    if (btn) {
      btn.addEventListener('click', function () {
        form.querySelectorAll('[data-row]').forEach(function (row) {
          var kills = parseInt(row.querySelector('[data-kills]').value, 10) || 0;
          var rank = parseInt(row.querySelector('[data-rank]').value, 10) || 0;
          var amount = kills * perKill + (rank === 1 ? winPrize : 0);
          row.querySelector('[data-amount]').value = amount;
          row.querySelector('[data-won]').checked = amount > 0;
        });
      });
    }
  }
})();

<?php

declare(strict_types=1);

require dirname(__DIR__, 2) . '/src/bootstrap.php';

App\Api\Api::boot();
(new App\Api\MetaApi())->instamojoToken();

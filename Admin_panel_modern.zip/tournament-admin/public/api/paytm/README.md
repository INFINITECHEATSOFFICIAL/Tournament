Legacy Paytm checksum kit (unchanged logic from Paytm's sample code).
Only the merchant key moved to `.env`. This is vendor code – review it against
Paytm's current documentation before relying on it; the live key from the old
config file was exposed and must be rotated in the Paytm dashboard.

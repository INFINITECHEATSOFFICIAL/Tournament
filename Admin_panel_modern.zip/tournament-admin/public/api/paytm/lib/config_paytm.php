<?php
// The Paytm merchant key now lives in .env (PAYTM_MERCHANT_KEY) – never commit it.
require_once dirname(__DIR__, 4) . '/src/bootstrap.php';

define('PAYTM_MERCHANT_KEY', env('PAYTM_MERCHANT_KEY', '') ?? '');

<?php
header('Content-Type: text/html; charset=UTF-8');
?><!doctype html><meta charset="utf-8"><title>Support</title><p>Support page – replace this text with your own content.</p>

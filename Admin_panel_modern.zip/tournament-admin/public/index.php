<?php

declare(strict_types=1);

require dirname(__DIR__) . '/src/bootstrap.php';

use App\Controllers\{AuthController, DashboardController, MatchController, MediaController, PlayerController, RuleController, ScoreController, SettingsController, TransactionController};
use App\Core\{Auth, Request, Response, Router, Session, View};

// Security headers (strict CSP: the UI uses no inline scripts or styles).
header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header('Cache-Control: no-store');

$request = Request::capture();

$router = new Router();
$router->get('/login', [AuthController::class, 'showLogin']);
$router->post('/login', [AuthController::class, 'login']);
$router->post('/logout', [AuthController::class, 'logout']);
$router->get('/setup', [AuthController::class, 'showSetup']);
$router->post('/setup', [AuthController::class, 'setup']);

$router->get('/', [DashboardController::class, 'index']);

$router->get('/matches', [MatchController::class, 'index']);
$router->get('/matches/create', [MatchController::class, 'create']);
$router->post('/matches', [MatchController::class, 'store']);
$router->get('/matches/{id}', [MatchController::class, 'show']);
$router->get('/matches/{id}/edit', [MatchController::class, 'edit']);
$router->post('/matches/{id}', [MatchController::class, 'update']);
$router->post('/matches/{id}/status', [MatchController::class, 'setStatus']);
$router->post('/matches/{id}/delete', [MatchController::class, 'destroy']);

$router->get('/scores', [ScoreController::class, 'index']);
$router->get('/scores/{id}', [ScoreController::class, 'show']);
$router->post('/scores/{id}', [ScoreController::class, 'save']);

$router->get('/players', [PlayerController::class, 'index']);
$router->get('/players/{id}', [PlayerController::class, 'show']);
$router->post('/players/{id}/wallet', [PlayerController::class, 'adjustWallet']);

$router->get('/transactions', [TransactionController::class, 'index']);
$router->get('/transactions/export', [TransactionController::class, 'export']);
$router->get('/withdrawals', [TransactionController::class, 'withdrawals']);
$router->post('/withdrawals/{id}', [TransactionController::class, 'updateWithdrawal']);

$router->get('/rules', [RuleController::class, 'index']);
$router->post('/rules', [RuleController::class, 'store']);
$router->post('/rules/{id}', [RuleController::class, 'update']);
$router->post('/rules/{id}/delete', [RuleController::class, 'destroy']);

$router->get('/media', [MediaController::class, 'index']);
$router->post('/media', [MediaController::class, 'upload']);
$router->post('/media/delete', [MediaController::class, 'delete']);

$router->get('/settings', [SettingsController::class, 'index']);
$router->post('/settings/password', [SettingsController::class, 'changePassword']);
$router->post('/settings/version', [SettingsController::class, 'updateVersion']);

try {
    Session::start();
    Session::rotateInput();

    $public = ['/login', '/setup'];
    if (!in_array($request->path, $public, true) && !Auth::check()) {
        if ($request->method === 'GET') {
            Session::set('intended', $request->path);
        }
        Response::redirect(url('/login'))->send();
        exit;
    }

    if ($request->isPost() && !Session::verifyCsrf($request->string('_token'))) {
        Response::html(View::render('errors/error', [
            'title' => 'Session expired',
            'code' => 419,
            'message' => 'Your form expired. Go back, refresh the page and try again.',
        ], 'layouts/auth'), 419)->send();
        exit;
    }

    $router->dispatch($request)->send();
} catch (Throwable $e) {
    error_log((string) $e);
    $debug = filter_var(env('APP_DEBUG', 'false'), FILTER_VALIDATE_BOOLEAN);
    http_response_code(500);
    echo View::render('errors/error', [
        'title' => 'Something went wrong',
        'code' => 500,
        'message' => $debug ? $e->getMessage() : 'An unexpected error occurred. It has been logged.',
    ], 'layouts/auth');
}

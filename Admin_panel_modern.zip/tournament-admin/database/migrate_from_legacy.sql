-- ══════════════════════════════════════════════════════════════════════
--  Upgrade an EXISTING 2019 BattleWorld database to the new schema
-- ══════════════════════════════════════════════════════════════════════
--  1. TAKE A FULL BACKUP FIRST (mysqldump).  Try it on a copy before production.
--  2. Put the site in maintenance mode while this runs.
--  3. Run section by section (phpMyAdmin → SQL, or `mysql db < file`).
--
--  What it does
--    • drops the three old triggers (balances are now handled in PHP – keeping
--      them would credit every transaction twice)
--    • converts every table to InnoDB / utf8mb4 / DATETIME (TIMESTAMP values are
--      converted using the session time zone, so match times keep the clock
--      value you see in phpMyAdmin today – check a few after running)
--    • merges duplicate wallet rows, removes orphans, adds keys & constraints
--    • creates the new admin tables
--  Plain-text passwords are NOT touched here: each is upgraded to a hash the
--  next time that player signs in.
-- ══════════════════════════════════════════════════════════════════════

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ── 0. Pre-flight checks – every query below should return 0 rows ───────
-- SELECT username, COUNT(*) c FROM `user` GROUP BY username HAVING c > 1;
-- SELECT email,    COUNT(*) c FROM `user` GROUP BY email    HAVING c > 1;
-- SELECT mobile,   COUNT(*) c FROM `user` GROUP BY mobile   HAVING c > 1;
-- SELECT matchid, userid, COUNT(*) c FROM matchdetail GROUP BY matchid, userid HAVING c > 1;
-- (Fix any duplicates by hand first – the unique keys below will fail otherwise.)

-- ── 1. Remove the old triggers ──────────────────────────────────────────
DROP TRIGGER IF EXISTS `totalplayerjoined`;
DROP TRIGGER IF EXISTS `newuserbalance`;
DROP TRIGGER IF EXISTS `updatebalance`;

-- ── 2. Tidy data before adding constraints ──────────────────────────────
DELETE FROM matchdetail     WHERE matchid NOT IN (SELECT matchid FROM matchmst);
DELETE FROM matchdetail     WHERE userid  NOT IN (SELECT userid  FROM `user`);
-- (ledger rows of deleted users are kept on purpose: financial history is never deleted)

UPDATE usertransaction SET instapaymentid = NULL WHERE instapaymentid = '';
UPDATE usertransaction SET instaorderid   = NULL WHERE instaorderid   = '';
UPDATE usertransaction SET instatxnid     = NULL WHERE instatxnid     = '';
UPDATE usertransaction SET instatoken     = NULL WHERE instatoken     = '';
UPDATE usertransaction SET paytmnumber    = NULL WHERE paytmnumber    = '';
UPDATE matchmst SET matchstatus = 'upcoming' WHERE matchstatus NOT IN ('upcoming','ongoing','done');
UPDATE matchmst SET type = 'SOLO' WHERE type IS NULL OR type = '';
UPDATE matchmst SET version = '1.0' WHERE version IS NULL OR version = '';
UPDATE matchmst SET map = 'Erangel' WHERE map IS NULL OR map = '';
UPDATE matchmst SET matchtype = IF(entryfee > 0, 'Paid', 'Free') WHERE matchtype IS NULL OR matchtype = '';
UPDATE matchmst SET totalplayerjoined = 0 WHERE totalplayerjoined IS NULL;
UPDATE matchmst SET totalplayer = 100 WHERE totalplayer IS NULL;
UPDATE matchmst SET entryfee = 0 WHERE entryfee IS NULL;
UPDATE matchmst SET winprice = 0 WHERE winprice IS NULL;
UPDATE matchmst SET perkill  = 0 WHERE perkill  IS NULL;
UPDATE matchmst SET joinstatus = 0 WHERE joinstatus IS NULL;
UPDATE matchdetail SET won = 'N' WHERE won IS NULL OR won = '';

-- Merge duplicate wallet rows (keep the lowest balanceid, sum the balances)
UPDATE userbalance b
  JOIN (SELECT userid, MIN(balanceid) keep_id, SUM(balance) total FROM userbalance GROUP BY userid) s
    ON s.userid = b.userid AND s.keep_id = b.balanceid
   SET b.balance = s.total;
DELETE b FROM userbalance b
  JOIN (SELECT userid, MIN(balanceid) keep_id FROM userbalance GROUP BY userid) s
    ON s.userid = b.userid AND b.balanceid <> s.keep_id;
INSERT INTO userbalance (userid, balance, log_entdate)
  SELECT u.userid, 0, NOW() FROM `user` u LEFT JOIN userbalance b ON b.userid = u.userid WHERE b.userid IS NULL;

-- Make participant counters truthful again
UPDATE matchmst m SET totalplayerjoined = (SELECT COUNT(*) FROM matchdetail d WHERE d.matchid = m.matchid);

-- ── 3. Convert tables ───────────────────────────────────────────────────
ALTER TABLE `user`
  ENGINE=InnoDB, CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  MODIFY `password` VARCHAR(255) NOT NULL,
  MODIFY `gender` VARCHAR(50) NULL,
  MODIFY `log_entdate` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ADD UNIQUE KEY `uq_user_username` (`username`),
  ADD UNIQUE KEY `uq_user_email` (`email`),
  ADD UNIQUE KEY `uq_user_mobile` (`mobile`);

ALTER TABLE `userbalance`
  ENGINE=InnoDB, CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  MODIFY `userid` INT NOT NULL,
  MODIFY `balance` INT NOT NULL DEFAULT 0,
  MODIFY `log_entdate` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ADD UNIQUE KEY `uq_balance_user` (`userid`);

ALTER TABLE `usertransaction`
  ENGINE=InnoDB, CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  MODIFY `userid` INT NOT NULL,
  MODIFY `type` INT NOT NULL DEFAULT 1,
  MODIFY `log_entdate` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ADD UNIQUE KEY `uq_trn_payment` (`instapaymentid`),
  ADD KEY `idx_trn_user` (`userid`, `trnid`),
  ADD KEY `idx_trn_date` (`log_entdate`);

ALTER TABLE `matchmst`
  ENGINE=InnoDB, CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  MODIFY `roomid` VARCHAR(30) NULL,
  MODIFY `roompassword` VARCHAR(30) NULL,
  MODIFY `map` VARCHAR(30) NOT NULL DEFAULT 'Erangel',
  MODIFY `type` VARCHAR(10) NOT NULL DEFAULT 'SOLO',
  MODIFY `version` VARCHAR(10) NOT NULL DEFAULT '1.0',
  MODIFY `matchtype` VARCHAR(10) NOT NULL DEFAULT 'Paid',
  MODIFY `totalplayer` INT NOT NULL DEFAULT 100,
  MODIFY `totalplayerjoined` INT NOT NULL DEFAULT 0,
  MODIFY `entryfee` INT NOT NULL DEFAULT 0,
  MODIFY `winprice` INT NOT NULL DEFAULT 0,
  MODIFY `perkill` INT NOT NULL DEFAULT 0,
  MODIFY `joinstatus` INT NOT NULL DEFAULT 0,
  MODIFY `matchstatus` VARCHAR(10) NOT NULL DEFAULT 'upcoming',
  MODIFY `matchschedule` DATETIME NOT NULL,
  MODIFY `log_entdate` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ADD KEY `idx_match_status` (`matchstatus`, `matchschedule`);

ALTER TABLE `matchdetail`
  ENGINE=InnoDB, CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  MODIFY `matchid` INT NOT NULL,
  MODIFY `userid` INT NOT NULL,
  MODIFY `won` VARCHAR(10) NOT NULL DEFAULT 'N',
  MODIFY `log_entdate` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ADD UNIQUE KEY `uq_match_user` (`matchid`, `userid`),
  ADD KEY `idx_detail_user` (`userid`);

ALTER TABLE `rules`
  ENGINE=InnoDB, CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  MODIFY `rules` VARCHAR(500) NOT NULL,
  MODIFY `remarkid` VARCHAR(200) NOT NULL DEFAULT 'basic',
  ADD KEY `idx_rules_remark` (`remarkid`);

ALTER TABLE `appversion`
  ENGINE=InnoDB, CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
-- appversion had no primary key; keep one row per name:
DELETE a FROM appversion a JOIN appversion b ON a.name = b.name AND (a.newversion < b.newversion);
ALTER TABLE `appversion` ADD PRIMARY KEY (`name`);

-- ── 4. Foreign keys ─────────────────────────────────────────────────────
ALTER TABLE `userbalance`     ADD CONSTRAINT `fk_balance_user`  FOREIGN KEY (`userid`) REFERENCES `user` (`userid`) ON DELETE CASCADE;
-- (no foreign key on usertransaction in migrated databases: old ledger rows may reference deleted users)
ALTER TABLE `matchdetail`     ADD CONSTRAINT `fk_detail_match`  FOREIGN KEY (`matchid`) REFERENCES `matchmst` (`matchid`) ON DELETE CASCADE;
ALTER TABLE `matchdetail`     ADD CONSTRAINT `fk_detail_user`   FOREIGN KEY (`userid`)  REFERENCES `user` (`userid`) ON DELETE CASCADE;

-- ── 5. New admin tables ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `admins` (
  `id`            INT NOT NULL AUTO_INCREMENT,
  `username`      VARCHAR(60)  NOT NULL,
  `display_name`  VARCHAR(100) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `is_active`     TINYINT(1)   NOT NULL DEFAULT 1,
  `last_login_at` DATETIME NULL,
  `created_at`    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_admin_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `login_attempts` (
  `id`         BIGINT NOT NULL AUTO_INCREMENT,
  `scope`      VARCHAR(20)  NOT NULL,
  `identifier` VARCHAR(100) NOT NULL,
  `ip`         VARCHAR(45)  NOT NULL,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_attempt_ident` (`scope`, `identifier`, `created_at`),
  KEY `idx_attempt_ip` (`scope`, `ip`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- Done. Open /setup in the browser to create your first administrator.

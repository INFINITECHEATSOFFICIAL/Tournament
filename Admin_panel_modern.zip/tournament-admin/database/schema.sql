-- BattleWorld / Tournament admin – fresh install schema
-- MySQL 5.7+ / MariaDB 10.3+   ·   InnoDB, utf8mb4, real keys, no triggers.
-- Existing installation?  Use migrate_from_legacy.sql instead.

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ── Admin panel ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `admins` (
  `id`            INT NOT NULL AUTO_INCREMENT,
  `username`      VARCHAR(60)  NOT NULL,
  `display_name`  VARCHAR(100) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `is_active`     TINYINT(1)   NOT NULL DEFAULT 1,
  `last_login_at` DATETIME NULL,
  `created_at`    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_admin_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `login_attempts` (
  `id`         BIGINT NOT NULL AUTO_INCREMENT,
  `scope`      VARCHAR(20)  NOT NULL,
  `identifier` VARCHAR(100) NOT NULL,
  `ip`         VARCHAR(45)  NOT NULL,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_attempt_ident` (`scope`, `identifier`, `created_at`),
  KEY `idx_attempt_ip` (`scope`, `ip`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── App data (same table/column names the mobile app already uses) ──
CREATE TABLE IF NOT EXISTS `appversion` (
  `name`       VARCHAR(100) NOT NULL DEFAULT 'BattleWorld',
  `oldversion` VARCHAR(100) NOT NULL DEFAULT '1.0',
  `newversion` VARCHAR(100) NOT NULL DEFAULT '1.0',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `user` (
  `userid`       INT NOT NULL AUTO_INCREMENT,
  `firstname`    VARCHAR(200) NOT NULL,
  `lastname`     VARCHAR(200) NOT NULL,
  `username`     VARCHAR(200) NOT NULL,
  `pubgusername` VARCHAR(250) NULL,
  `gender`       VARCHAR(50)  NULL,
  `email`        VARCHAR(200) NOT NULL,
  `mobile`       VARCHAR(100) NOT NULL,
  `password`     VARCHAR(255) NOT NULL,          -- bcrypt/argon2 hash (legacy plain text is upgraded at next login)
  `other`        VARCHAR(500) NULL,
  `promocode`    VARCHAR(100) NULL,
  `log_entdate`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`userid`),
  UNIQUE KEY `uq_user_username` (`username`),
  UNIQUE KEY `uq_user_email` (`email`),
  UNIQUE KEY `uq_user_mobile` (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `userbalance` (
  `balanceid`   INT NOT NULL AUTO_INCREMENT,
  `userid`      INT NOT NULL,
  `balance`     INT NOT NULL DEFAULT 0,
  `log_entdate` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`balanceid`),
  UNIQUE KEY `uq_balance_user` (`userid`),
  CONSTRAINT `fk_balance_user` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `usertransaction` (
  `trnid`          INT NOT NULL AUTO_INCREMENT,
  `userid`         INT NOT NULL,
  `amount`         INT NOT NULL,                 -- signed: + credit, - debit
  `type`           INT NOT NULL DEFAULT 1,       -- 1 = credit, 0 = debit (kept for the app)
  `paytmnumber`    VARCHAR(100) NULL,
  `instaorderid`   VARCHAR(250) NULL,
  `instatxnid`     VARCHAR(250) NULL,
  `instapaymentid` VARCHAR(250) NULL,
  `instatoken`     VARCHAR(250) NULL,
  `status`         VARCHAR(250) NOT NULL,
  `log_entdate`    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`trnid`),
  UNIQUE KEY `uq_trn_payment` (`instapaymentid`),   -- a payment can only be credited once
  KEY `idx_trn_user` (`userid`, `trnid`),
  KEY `idx_trn_date` (`log_entdate`),
  CONSTRAINT `fk_trn_user` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `matchmst` (
  `matchid`           INT NOT NULL AUTO_INCREMENT,
  `roomid`            VARCHAR(30) NULL,
  `roompassword`      VARCHAR(30) NULL,
  `type`              VARCHAR(10) NOT NULL DEFAULT 'SOLO',
  `version`           VARCHAR(10) NOT NULL DEFAULT '1.0',
  `map`               VARCHAR(30) NOT NULL DEFAULT 'Erangel',
  `maintopbannerimg`  VARCHAR(250) NULL,
  `iconimg`           VARCHAR(250) NULL,
  `matchtype`         VARCHAR(10) NOT NULL DEFAULT 'Paid',
  `totalplayer`       INT NOT NULL DEFAULT 100,
  `totalplayerjoined` INT NOT NULL DEFAULT 0,
  `entryfee`          INT NOT NULL DEFAULT 0,
  `winprice`          INT NOT NULL DEFAULT 0,
  `perkill`           INT NOT NULL DEFAULT 0,
  `joinstatus`        INT NOT NULL DEFAULT 0,
  `matchstatus`       VARCHAR(10) NOT NULL DEFAULT 'upcoming',
  `matchschedule`     DATETIME NOT NULL,
  `log_entdate`       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`matchid`),
  KEY `idx_match_status` (`matchstatus`, `matchschedule`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `matchdetail` (
  `matchdetailid` INT NOT NULL AUTO_INCREMENT,
  `matchid`       INT NOT NULL,
  `userid`        INT NOT NULL,
  `wonamount`     INT NOT NULL DEFAULT 0,
  `kills`         INT NOT NULL DEFAULT 0,
  `rank`          INT NULL,
  `won`           VARCHAR(10) NOT NULL DEFAULT 'N',
  `log_entdate`   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`matchdetailid`),
  UNIQUE KEY `uq_match_user` (`matchid`, `userid`),  -- a player can join a match only once
  KEY `idx_detail_user` (`userid`),
  CONSTRAINT `fk_detail_match` FOREIGN KEY (`matchid`) REFERENCES `matchmst` (`matchid`) ON DELETE CASCADE,
  CONSTRAINT `fk_detail_user`  FOREIGN KEY (`userid`)  REFERENCES `user` (`userid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `rules` (
  `rulesid`  INT NOT NULL AUTO_INCREMENT,
  `rules`    VARCHAR(500) NOT NULL,
  `remarkid` VARCHAR(200) NOT NULL DEFAULT 'basic',
  PRIMARY KEY (`rulesid`),
  KEY `idx_rules_remark` (`remarkid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

INSERT IGNORE INTO `appversion` (`name`, `oldversion`, `newversion`) VALUES ('BattleWorld', '1.0', '1.0');

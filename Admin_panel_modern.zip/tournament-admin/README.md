# BattleWorld Tournament Admin — modern rewrite

A ground-up rewrite of the 2019 PHP admin panel and mobile-app API.
**PHP 8.1+ · MySQL 5.7+/MariaDB 10.3+ · no Composer, no frameworks, no CDN** — it still runs on ordinary shared hosting (cPanel).

> ⚠️ **Not run against a live database yet.** The sandbox this was written in had no PHP or MySQL, so the code
> was reviewed and syntax-balanced but never executed. Deploy to a **staging copy first** and walk through the checklist at the bottom.

---------------------------------------------------------------------------

## What's in the box

```
public/               ← web root (point your domain here)
  index.php           front controller for the admin panel
  assets/             css (light + dark), js (vanilla, no jQuery)
  api/                mobile-app endpoints (same file names as before)
  uploads/matchimg/   banners / icons / lottie json
src/                  Core (router, DB, session, auth…), Controllers, Services, Api
templates/            views (all output escaped, strict CSP – no inline JS/CSS)
database/             schema.sql (fresh) · migrate_from_legacy.sql (existing data)
bin/                  create-admin.php · nginx.conf.example
storage/logs/         PHP error log (not web-accessible)
.env.example          configuration template
```

### Admin panel
| Old | New |
|---|---|
| Hard-coded `admin / 123456` in `login.php` | `admins` table, bcrypt hashes, brute-force lockout, session-fixation protection, CSRF on every form, idle timeout |
| Match Master: 4 tabs, type an ID to edit/delete | Match list with filters/search/paging, create/edit form (date picker, validation), quick **Start**, delete with automatic entry-fee refunds |
| Score update: click-to-edit cells, one AJAX call per row | One form for the whole match, **Auto-calculate** button, "mark completed" |
| Re-saving a score **paid the player again** | Only the *difference* is credited/debited |
| Players page showed **plain-text passwords** | Searchable list + profile page (stats, matches, wallet history, manual wallet adjust). Passwords are never shown |
| Transactions: 3 raw tables | Filters (type, direction, dates, search), totals, CSV export |
| Withdrawals: edit a free-text "remark" | Pending / Completed / Rejected tabs with **Paid** and **Reject (auto-refund)** buttons |
| — | Dashboard, Rules editor, Media manager, App-version setting, change-password, dark mode, mobile layout |

### Mobile API (`public/api/*.php`)
File names, parameters and JSON shape (`success`, `message`, `rajanr`, `rajanruser`, `rajanrwon`, values as strings) are unchanged,
so the app should keep working. Internals: PDO prepared statements everywhere (the old code was injectable on every endpoint).

---------------------------------------------------------------------------

## Install — new database
1. Upload the project; set the domain's **document root to `public/`** (cPanel → Domains → Document Root).
2. `cp .env.example .env` and fill in `DB_*`.
3. Import `database/schema.sql`.
4. Open `https://your-domain/setup` and create the administrator (or `php bin/create-admin.php admin "Your Name"`).
5. Make `storage/logs` and `public/uploads` writable by PHP (`chmod 775`).

## Install — upgrading your existing database
1. **Back up the database.** Test on a copy.
2. Run the pre-flight `SELECT`s at the top of `database/migrate_from_legacy.sql` (duplicates must be fixed by hand).
3. Run the script. It drops the old triggers (required — balances are now handled in PHP, keeping them would double-credit), converts tables to InnoDB/utf8mb4, merges duplicate wallet rows and adds keys.
4. Existing players keep their plain-text passwords for now; **each is replaced by a bcrypt hash the next time that player signs in.**
5. Continue from step 1–2 and 4–5 above.

### Keeping the old app URLs
`public/.htaccess` rewrites `/battleworld/<name>.php → /api/<name>.php` and `/battleworld/matchimg/* → /uploads/matchimg/*`.
If the new site lives on the same domain as the old one, **the app needs no update.** (nginx rules are in `bin/nginx.conf.example`.)

---------------------------------------------------------------------------

## 🔐 Do this now — secrets in the old zip
The zip you uploaded contained live credentials in plain text. Treat all of them as leaked and **rotate** them:
* MySQL user/password (`db_config.php`)
* Instamojo **live** client id & secret (`access_token.php`) and the test pair
* Paytm merchant key (`paytm/lib/config_paytm.php`)
* An Envato author API token (hard-coded in every admin page) — it belongs to the item's author, not to you
* The `admin / 123456` panel login

All of these now come from `.env` (never committed). Also delete the old `error_log` files from the server — they contain file paths and queries.

> **Licence check removed.** The old pages called Envato's API with the seller's token on every request to validate a purchase code.
> That mechanism is gone in this rewrite. Please make sure your CodeCanyon licence allows modified/derived copies.

---------------------------------------------------------------------------

## Intentional behaviour changes (API)
| Endpoint | Before | Now |
|---|---|---|
| `join_match` | Trusted the `entryfee` sent by the phone, no balance/capacity/duplicate check | Fee, status and capacity read from the DB; balance checked; one join per match; all in one DB transaction. The `entryfee` parameter is accepted but ignored |
| `payment` | Credited **any amount the app claimed** — free money for anyone with curl | Verified with Instamojo before crediting (`PAYMENT_VERIFY_MODE`), idempotent per payment id |
| `withdraw` | Positive amount + trigger → balance went *up* unless the app sent a negative number | Always debits immediately; admin **Reject** refunds |
| `signin_user` | Returned the password; echoed it in error messages | Never returns/echoes passwords (`password` key is present but empty) |
| `get_all_match`, `get_match_details`, results | Room ID/password sent to everyone | Only to players who joined that match |
| `app_updater` | Always answered `"1.0"` | Returns the version saved under Settings |
| `edit_profile` | Could take another player's mobile number | Rejects duplicate mobile numbers |
| all | `MYSQLI_BOTH` (every field twice: by name and index) | Named keys only. If your app reads fields by numeric index, tell me and I'll add them back |
| `matchimg/upload.php` | Open to the internet | Removed — uploads are in the admin under **Media** (login required, type/size checked) |

### Payment verification — please test
`PAYMENT_VERIFY_MODE=instamojo` calls Instamojo's `GET /v2/payments/<id>/` and expects a successful status and matching amount.
I wrote this from Instamojo's documented v2 API but could not test it against your account. **Make one test payment in Instamojo test mode before going live.**
If verification rejects genuine payments, check `storage/logs/php-error.log`. `trust` restores the old insecure behaviour; `disabled` blocks deposits.

### Still weak (needs an app update to fix)
The app identifies players only by `userid` — there are no login tokens — so anyone who guesses a user id can read that player's
data or join matches for them (their own money is protected by the wallet checks, but not their privacy). The proper fix is issuing a
token at sign-in and requiring it on every call; that needs a matching change in the Android app.

---------------------------------------------------------------------------

## Configuration (`.env`)
See `.env.example`. Notable: `APP_TIMEZONE` (default `Asia/Kolkata`), `CURRENCY_SYMBOL`, `LOGIN_MAX_ATTEMPTS`, `PAYMENT_VERIFY_MODE`.
Map / mode lists live in `src/Support/Options.php`.

## First-run checklist (staging)
- [ ] `/setup` creates the admin; sign-out/sign-in works; wrong password 5× locks you out for 15 min
- [ ] Create a match → appears in the app's upcoming list; room id hidden until you join
- [ ] Join with a test player (check balance drops once, `totalplayerjoined` +1, second join refused)
- [ ] Scores: enter winnings, save **twice** → wallet credited once
- [ ] Withdraw from the app → shows under Withdrawals → Reject refunds, Paid keeps it debited
- [ ] Test Instamojo payment (see above)
- [ ] Existing player can still sign in; their row now holds a `$2y$…` hash
- [ ] Upload a banner under Media and select it on a match

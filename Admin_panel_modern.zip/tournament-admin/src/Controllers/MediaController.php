<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Services\Media;

final class MediaController extends Controller
{
    public function index(Request $request): Response
    {
        $images = [];
        foreach (Media::images() as $f) {
            $path = Media::dir() . '/' . $f;
            $images[] = ['name' => $f, 'size' => (int) @filesize($path), 'used' => Media::usageCount($f)];
        }
        $anims = [];
        foreach (Media::animations() as $f) {
            $anims[] = ['name' => $f, 'size' => (int) @filesize(Media::dir('images') . '/' . $f)];
        }
        return $this->view('media/index', [
            'title' => 'Media',
            'active' => 'media',
            'images' => $images,
            'animations' => $anims,
        ]);
    }

    public function upload(Request $request): Response
    {
        $files = $_FILES['files'] ?? null;
        if (!$files || !is_array($files['name'])) {
            return $this->redirect('/media', 'error', 'Choose at least one file.');
        }
        $ok = 0;
        $problems = [];
        foreach (array_keys($files['name']) as $i) {
            if (($files['error'][$i] ?? 0) === UPLOAD_ERR_NO_FILE) {
                continue;
            }
            $res = Media::store([
                'name' => $files['name'][$i],
                'tmp_name' => $files['tmp_name'][$i],
                'size' => $files['size'][$i],
                'error' => $files['error'][$i],
            ]);
            if ($res['ok']) {
                $ok++;
            } else {
                $problems[] = $files['name'][$i] . ': ' . $res['message'];
            }
        }
        if ($problems) {
            \App\Core\Session::flash('error', implode(' · ', $problems));
        }
        return $this->redirect('/media', $ok ? 'success' : 'info', $ok ? "{$ok} file(s) uploaded." : 'Nothing was uploaded.');
    }

    public function delete(Request $request): Response
    {
        $name = basename($request->string('name'));
        $kind = $request->string('kind') === 'animation' ? 'animation' : 'image';
        if ($kind === 'image' && Media::usageCount($name) > 0) {
            return $this->redirect('/media', 'error', 'That image is used by one or more matches. Change those matches first.');
        }
        $ok = Media::delete($name, $kind);
        return $this->redirect('/media', $ok ? 'success' : 'error', $ok ? 'File deleted.' : 'File not found.');
    }
}

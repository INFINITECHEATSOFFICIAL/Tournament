<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Core\Paginator;
use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Core\Validator;
use App\Services\Media;
use App\Services\Wallet;
use App\Support\Options;

final class MatchController extends Controller
{
    public function index(Request $request): Response
    {
        $status = $request->string('status');
        $q = $request->string('q');
        $where = ['1=1'];
        $params = [];

        if (in_array($status, Options::STATUSES, true)) {
            $where[] = 'matchstatus = ?';
            $params[] = $status;
        }
        if ($q !== '') {
            $where[] = '(matchid = ? OR map LIKE ? OR roomid LIKE ? OR type LIKE ?)';
            $params[] = ctype_digit($q) ? (int) $q : 0;
            $like = '%' . addcslashes($q, '%_\\') . '%';
            array_push($params, $like, $like, $like);
        }
        $whereSql = implode(' AND ', $where);

        $total = (int) Database::value("SELECT COUNT(*) FROM matchmst WHERE {$whereSql}", $params);
        $pager = new Paginator($total, $request->int('page', 1), 15);

        $matches = Database::all(
            "SELECT matchid, roomid, type, map, matchtype, entryfee, winprice, perkill, totalplayer,
                    totalplayerjoined, matchstatus, matchschedule
               FROM matchmst WHERE {$whereSql}
              ORDER BY matchschedule DESC, matchid DESC" . $pager->limitSql(),
            $params
        );

        $counts = ['all' => 0];
        foreach (Database::all('SELECT matchstatus, COUNT(*) AS c FROM matchmst GROUP BY matchstatus') as $r) {
            $counts[strtolower((string) $r['matchstatus'])] = (int) $r['c'];
            $counts['all'] += (int) $r['c'];
        }

        return $this->view('matches/index', [
            'title' => 'Matches',
            'active' => 'matches',
            'matches' => $matches,
            'pager' => $pager,
            'counts' => $counts,
            'status' => $status,
            'q' => $q,
        ]);
    }

    public function create(Request $request): Response
    {
        return $this->view('matches/form', $this->formData('New match', null));
    }

    public function store(Request $request): Response
    {
        $v = $this->validate($request, null);
        if ($v->fails()) {
            return $this->backWithErrors('/matches/create', $request, $v->errors);
        }
        $d = $v->clean;

        $id = Database::insert(
            'INSERT INTO matchmst
                (roomid, roompassword, type, version, map, maintopbannerimg, iconimg, matchtype, totalplayer,
                 totalplayerjoined, entryfee, winprice, perkill, joinstatus, matchstatus, matchschedule, log_entdate)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, 0, ?, ?, ?)',
            [
                $d['roomid'], $d['roompassword'], $d['type'], $d['version'], $d['map'], $d['maintopbannerimg'],
                $d['iconimg'], $d['matchtype'], $d['totalplayer'], $d['entryfee'], $d['winprice'], $d['perkill'],
                $d['matchstatus'], $d['matchschedule'], date('Y-m-d H:i:s'),
            ]
        );

        return $this->redirect("/matches/{$id}", 'success', "Match #{$id} created.");
    }

    public function show(Request $request, int $id): Response
    {
        $match = Database::one('SELECT * FROM matchmst WHERE matchid = ?', [$id]);
        if (!$match) {
            return $this->notFound('Match');
        }

        $players = Database::all(
            'SELECT d.userid, d.kills, d.`rank`, d.won, d.wonamount, d.log_entdate,
                    u.username, u.firstname, u.lastname, u.pubgusername
               FROM matchdetail d
               JOIN `user` u ON u.userid = d.userid
              WHERE d.matchid = ?
              ORDER BY d.wonamount DESC, d.kills DESC, d.matchdetailid ASC',
            [$id]
        );

        return $this->view('matches/show', [
            'title' => "Match #{$id}",
            'active' => 'matches',
            'match' => $match,
            'players' => $players,
        ]);
    }

    public function edit(Request $request, int $id): Response
    {
        $match = Database::one('SELECT * FROM matchmst WHERE matchid = ?', [$id]);
        if (!$match) {
            return $this->notFound('Match');
        }
        return $this->view('matches/form', $this->formData("Edit match #{$id}", $match));
    }

    public function update(Request $request, int $id): Response
    {
        $match = Database::one('SELECT * FROM matchmst WHERE matchid = ?', [$id]);
        if (!$match) {
            return $this->notFound('Match');
        }

        $v = $this->validate($request, $match);
        if ($v->fails()) {
            return $this->backWithErrors("/matches/{$id}/edit", $request, $v->errors);
        }
        $d = $v->clean;

        Database::exec(
            'UPDATE matchmst SET roomid = ?, roompassword = ?, type = ?, version = ?, map = ?, maintopbannerimg = ?,
                    iconimg = ?, matchtype = ?, totalplayer = ?, entryfee = ?, winprice = ?, perkill = ?,
                    matchstatus = ?, matchschedule = ?
              WHERE matchid = ?',
            [
                $d['roomid'], $d['roompassword'], $d['type'], $d['version'], $d['map'], $d['maintopbannerimg'],
                $d['iconimg'], $d['matchtype'], $d['totalplayer'], $d['entryfee'], $d['winprice'], $d['perkill'],
                $d['matchstatus'], $d['matchschedule'], $id,
            ]
        );

        return $this->redirect("/matches/{$id}", 'success', "Match #{$id} updated.");
    }

    /** Quick status change from the list (Start / Finish). */
    public function setStatus(Request $request, int $id): Response
    {
        $status = $request->string('status');
        if (!in_array($status, Options::STATUSES, true)) {
            return $this->redirect('/matches', 'error', 'Unknown status.');
        }
        $changed = Database::exec('UPDATE matchmst SET matchstatus = ? WHERE matchid = ?', [$status, $id]);
        $back = $this->safeReturn($request, '/matches');
        return $this->redirect($back, $changed ? 'success' : 'info', $changed ? "Match #{$id} is now {$status}." : 'Nothing changed.');
    }

    /**
     * Delete a match. Entry fees of non-finished matches are refunded to the players first.
     * Finished matches that have participants are protected (their payouts are history).
     */
    public function destroy(Request $request, int $id): Response
    {
        $match = Database::one('SELECT matchid, matchstatus, matchtype, entryfee FROM matchmst WHERE matchid = ?', [$id]);
        if (!$match) {
            return $this->notFound('Match');
        }

        $participants = Database::all('SELECT userid FROM matchdetail WHERE matchid = ?', [$id]);

        if ($participants && strtolower((string) $match['matchstatus']) === 'done') {
            return $this->redirect('/matches', 'error', 'Completed matches with players cannot be deleted – they are part of the payout history.');
        }

        $refunded = 0;
        Database::transaction(function () use ($id, $match, $participants, &$refunded): void {
            $fee = (int) $match['entryfee'];
            if ($fee > 0 && strtolower((string) $match['matchtype']) === 'paid') {
                foreach ($participants as $p) {
                    Wallet::apply((int) $p['userid'], $fee, "MatchRefund#{$id}");
                    $refunded++;
                }
            }
            Database::exec('DELETE FROM matchdetail WHERE matchid = ?', [$id]);
            Database::exec('DELETE FROM matchmst WHERE matchid = ?', [$id]);
        });

        $msg = "Match #{$id} deleted.";
        if ($refunded > 0) {
            $msg .= " Entry fee refunded to {$refunded} player(s).";
        }
        return $this->redirect('/matches', 'success', $msg);
    }

    // ── helpers ───────────────────────────────────────────────────────
    private function formData(string $title, ?array $match): array
    {
        $images = Media::images();
        // Keep a value that is no longer on disk selectable so editing doesn't silently change it.
        foreach (['maintopbannerimg', 'iconimg'] as $col) {
            if ($match && !empty($match[$col]) && !in_array($match[$col], $images, true)) {
                $images[] = (string) $match[$col];
            }
        }
        return [
            'title' => $title,
            'active' => 'matches',
            'match' => $match,
            'images' => $images,
            'maps' => Options::MAPS,
            'types' => Options::MATCH_TYPES,
            'feeTypes' => Options::FEE_TYPES,
            'statuses' => Options::STATUSES,
            'versions' => Options::VERSIONS,
            'errors' => Session::errors(),
        ];
    }

    private function validate(Request $request, ?array $existing): Validator
    {
        $v = new Validator($request->post());
        $v->in('type', 'match type', Options::MATCH_TYPES)
          ->string('version', 'Version', 1, 10)
          ->string('map', 'Map', 1, 30)
          ->string('maintopbannerimg', 'Banner image', 0, 250, false)
          ->string('iconimg', 'Icon image', 0, 250, false)
          ->in('matchtype', 'fee type', Options::FEE_TYPES)
          ->int('totalplayer', 'Total players', 1, 1000)
          ->int('entryfee', 'Entry fee', 0, 1000000, false)
          ->int('winprice', 'Winning prize', 0, 100000000, false)
          ->int('perkill', 'Per-kill prize', 0, 1000000, false)
          ->in('matchstatus', 'status', Options::STATUSES)
          ->datetime('matchschedule', 'Match date & time')
          ->string('roomid', 'Room ID', 0, 30, false)
          ->string('roompassword', 'Room password', 0, 30, false);

        $d = &$v->clean;
        $d['entryfee'] = (int) ($d['entryfee'] ?? 0);
        $d['winprice'] = (int) ($d['winprice'] ?? 0);
        $d['perkill'] = (int) ($d['perkill'] ?? 0);

        if (($d['matchtype'] ?? '') === 'Free') {
            $d['entryfee'] = 0;
        } elseif (($d['matchtype'] ?? '') === 'Paid' && $d['entryfee'] < 1 && !isset($v->errors['entryfee'])) {
            $v->errors['entryfee'] = 'A paid match needs an entry fee above 0 (or choose Free).';
        }

        if ($existing && isset($d['totalplayer']) && $d['totalplayer'] < (int) $existing['totalplayerjoined']) {
            $v->errors['totalplayer'] = 'Cannot be lower than the ' . (int) $existing['totalplayerjoined'] . ' players who already joined.';
        }

        // Room credentials are only meaningful as a pair (same rule as before).
        if (empty($d['roomid']) || empty($d['roompassword'])) {
            $d['roomid'] = null;
            $d['roompassword'] = null;
        }
        foreach (['maintopbannerimg', 'iconimg'] as $col) {
            $d[$col] = !empty($d[$col]) ? basename((string) $d[$col]) : null;
        }
        return $v;
    }

    private function safeReturn(Request $request, string $default): string
    {
        $r = $request->string('return');
        return ($r !== '' && str_starts_with($r, '/') && !str_starts_with($r, '//')) ? $r : $default;
    }
}

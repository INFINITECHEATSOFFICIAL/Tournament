<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Core\Paginator;
use App\Core\Request;
use App\Core\Response;
use App\Services\Wallet;
use App\Support\WithdrawalState;

final class TransactionController extends Controller
{
    private const KINDS = [
        'deposit' => 't.instapaymentid IS NOT NULL',
        'entry' => "t.status LIKE 'JoinMatch#%'",
        'winning' => "t.status LIKE 'MatchWinning%'",
        'withdrawal' => "t.status LIKE '%withdrawal%'",
        'admin' => "t.status LIKE 'Admin%'",
        'refund' => "(t.status LIKE 'MatchRefund#%' OR t.status LIKE 'Refund for%')",
    ];

    /** @return array{0:string,1:array} */
    private function filters(Request $request): array
    {
        $where = ['1=1'];
        $params = [];

        $q = $request->string('q');
        if ($q !== '') {
            $like = '%' . addcslashes($q, '%_\\') . '%';
            $where[] = '(u.username LIKE ? OR u.firstname LIKE ? OR u.lastname LIKE ? OR t.userid = ? OR t.status LIKE ? OR t.paytmnumber LIKE ?)';
            array_push($params, $like, $like, $like, ctype_digit($q) ? (int) $q : 0, $like, $like);
        }

        $kind = $request->string('kind');
        if (isset(self::KINDS[$kind])) {
            $where[] = self::KINDS[$kind];
        }

        $dir = $request->string('direction');
        if ($dir === 'credit') {
            $where[] = 't.amount > 0';
        } elseif ($dir === 'debit') {
            $where[] = 't.amount < 0';
        }

        $from = $request->string('from');
        $to = $request->string('to');
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) {
            $where[] = 't.log_entdate >= ?';
            $params[] = $from . ' 00:00:00';
        }
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)) {
            $where[] = 't.log_entdate <= ?';
            $params[] = $to . ' 23:59:59';
        }

        return [implode(' AND ', $where), $params];
    }

    public function index(Request $request): Response
    {
        [$where, $params] = $this->filters($request);
        $from = ' FROM usertransaction t LEFT JOIN `user` u ON u.userid = t.userid WHERE ' . $where;

        $sum = Database::one(
            'SELECT COUNT(*) AS c, COALESCE(SUM(CASE WHEN t.amount > 0 THEN t.amount END), 0) AS credits,
                    COALESCE(SUM(CASE WHEN t.amount < 0 THEN t.amount END), 0) AS debits' . $from,
            $params
        ) ?? ['c' => 0, 'credits' => 0, 'debits' => 0];

        $pager = new Paginator((int) $sum['c'], $request->int('page', 1), 25);
        $rows = Database::all(
            'SELECT t.trnid, t.userid, t.amount, t.type, t.paytmnumber, t.status, t.log_entdate,
                    u.username, u.firstname, u.lastname' . $from . ' ORDER BY t.trnid DESC' . $pager->limitSql(),
            $params
        );

        return $this->view('transactions/index', [
            'title' => 'Transactions',
            'active' => 'transactions',
            'rows' => $rows,
            'pager' => $pager,
            'sum' => $sum,
            'kinds' => array_keys(self::KINDS),
            'f' => [
                'q' => $request->string('q'),
                'kind' => $request->string('kind'),
                'direction' => $request->string('direction'),
                'from' => $request->string('from'),
                'to' => $request->string('to'),
            ],
        ]);
    }

    public function export(Request $request): Response
    {
        [$where, $params] = $this->filters($request);
        $rows = Database::all(
            'SELECT t.trnid, t.userid, u.username, t.amount, t.type, t.paytmnumber, t.status, t.log_entdate
               FROM usertransaction t LEFT JOIN `user` u ON u.userid = t.userid
              WHERE ' . $where . ' ORDER BY t.trnid DESC LIMIT 20000',
            $params
        );

        $fh = fopen('php://temp', 'r+');
        fputcsv($fh, ['ID', 'User ID', 'Username', 'Amount', 'Direction', 'Paytm number', 'Remark', 'Date'], ',', '"', '\\');
        foreach ($rows as $r) {
            fputcsv($fh, [
                $r['trnid'], $r['userid'], $this->csvSafe((string) $r['username']), $r['amount'],
                (int) $r['amount'] >= 0 ? 'Credit' : 'Debit', $this->csvSafe((string) $r['paytmnumber']),
                $this->csvSafe((string) $r['status']), $r['log_entdate'],
            ], ',', '"', '\\');
        }
        rewind($fh);
        $csv = (string) stream_get_contents($fh);
        fclose($fh);

        return Response::download("\xEF\xBB\xBF" . $csv, 'transactions-' . date('Ymd-His') . '.csv', 'text/csv; charset=UTF-8');
    }

    /** Neutralise spreadsheet formula injection (=, +, -, @ at the start of a cell). */
    private function csvSafe(string $value): string
    {
        return ($value !== '' && strpbrk($value[0], "=+-@\t\r") !== false) ? "'" . $value : $value;
    }

    // ── Withdrawals ───────────────────────────────────────────────────
    public function withdrawals(Request $request): Response
    {
        $state = $request->string('state', WithdrawalState::PENDING);
        if (!in_array($state, [WithdrawalState::PENDING, WithdrawalState::COMPLETED, WithdrawalState::REJECTED, 'all'], true)) {
            $state = WithdrawalState::PENDING;
        }

        $base = WithdrawalState::isWithdrawalSql();
        $stateSql = $state === 'all' ? '1=1' : WithdrawalState::sql($state);

        $counts = [];
        foreach ([WithdrawalState::PENDING, WithdrawalState::COMPLETED, WithdrawalState::REJECTED] as $s) {
            $counts[$s] = (int) Database::value(
                "SELECT COUNT(*) FROM usertransaction t WHERE {$base} AND " . WithdrawalState::sql($s)
            );
        }
        $counts['all'] = array_sum($counts);

        $pager = new Paginator($counts[$state] ?? $counts['all'], $request->int('page', 1), 25);
        $rows = Database::all(
            "SELECT t.trnid, t.userid, t.amount, t.paytmnumber, t.status, t.log_entdate,
                    u.username, u.firstname, u.lastname, u.mobile
               FROM usertransaction t LEFT JOIN `user` u ON u.userid = t.userid
              WHERE {$base} AND {$stateSql}
              ORDER BY t.trnid DESC" . $pager->limitSql()
        );

        return $this->view('transactions/withdrawals', [
            'title' => 'Withdrawals',
            'active' => 'withdrawals',
            'rows' => $rows,
            'pager' => $pager,
            'counts' => $counts,
            'state' => $state,
        ]);
    }

    public function updateWithdrawal(Request $request, int $id): Response
    {
        $action = $request->string('action');
        $note = mb_substr($request->string('note'), 0, 80);
        $back = '/withdrawals?state=' . urlencode($request->string('state', WithdrawalState::PENDING));

        if (!in_array($action, ['complete', 'reject', 'reopen'], true)) {
            return $this->redirect($back, 'error', 'Unknown action.');
        }

        $message = '';
        $type = 'success';

        Database::transaction(function () use ($id, $action, $note, &$message, &$type): void {
            $row = Database::one(
                'SELECT trnid, userid, amount, status FROM usertransaction t
                  WHERE trnid = ? AND ' . WithdrawalState::isWithdrawalSql() . ' FOR UPDATE',
                [$id]
            );
            if (!$row) {
                $message = 'Withdrawal not found.';
                $type = 'error';
                return;
            }

            $state = WithdrawalState::classify((string) $row['status']);
            if ($state === WithdrawalState::REJECTED) {
                $message = 'This withdrawal was already rejected and refunded.';
                $type = 'error';
                return;
            }

            $suffix = $note !== '' ? " ({$note})" : '';

            if ($action === 'complete') {
                Database::exec('UPDATE usertransaction SET status = ? WHERE trnid = ?', [WithdrawalState::LABEL_COMPLETED . $suffix, $id]);
                $message = "Withdrawal #{$id} marked as completed.";
            } elseif ($action === 'reopen') {
                Database::exec('UPDATE usertransaction SET status = ? WHERE trnid = ?', [WithdrawalState::LABEL_PENDING, $id]);
                $message = "Withdrawal #{$id} moved back to pending.";
            } else { // reject → refund
                if ($state === WithdrawalState::COMPLETED) {
                    $message = 'A completed withdrawal cannot be rejected. Re-open it first.';
                    $type = 'error';
                    return;
                }
                Database::exec('UPDATE usertransaction SET status = ? WHERE trnid = ?', [WithdrawalState::LABEL_REJECTED . $suffix, $id]);
                $amount = (int) $row['amount'];
                if ($amount < 0) {
                    Wallet::apply((int) $row['userid'], -$amount, "Refund for rejected payout #{$id}");
                    $message = "Withdrawal #{$id} rejected and " . money(-$amount) . ' refunded to the player.';
                } else {
                    $message = "Withdrawal #{$id} rejected. It is an old record stored with a positive amount, so no refund was issued – check the player's wallet manually.";
                    $type = 'warning';
                }
            }
        });

        return $this->redirect($back, $type, $message);
    }
}

<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Core\Request;
use App\Core\Response;
use App\Support\WithdrawalState;

final class DashboardController extends Controller
{
    public function index(Request $request): Response
    {
        $since7 = date('Y-m-d H:i:s', strtotime('-7 days'));
        $since30 = date('Y-m-d H:i:s', strtotime('-30 days'));

        $matchCounts = ['upcoming' => 0, 'ongoing' => 0, 'done' => 0];
        foreach (Database::all('SELECT matchstatus, COUNT(*) AS c FROM matchmst GROUP BY matchstatus') as $r) {
            $matchCounts[strtolower((string) $r['matchstatus'])] = (int) $r['c'];
        }

        $pending = Database::one(
            'SELECT COUNT(*) AS c, COALESCE(SUM(ABS(t.amount)), 0) AS total
               FROM usertransaction t
              WHERE ' . WithdrawalState::isWithdrawalSql() . ' AND ' . WithdrawalState::sql(WithdrawalState::PENDING)
        ) ?? ['c' => 0, 'total' => 0];

        $stats = [
            'players' => (int) Database::value('SELECT COUNT(*) FROM `user`'),
            'new_players' => (int) Database::value('SELECT COUNT(*) FROM `user` WHERE log_entdate >= ?', [$since7]),
            'wallet_total' => (int) Database::value('SELECT COALESCE(SUM(balance), 0) FROM userbalance'),
            'deposits_30d' => (int) Database::value(
                'SELECT COALESCE(SUM(amount), 0) FROM usertransaction WHERE instapaymentid IS NOT NULL AND amount > 0 AND log_entdate >= ?',
                [$since30]
            ),
            'payouts_30d' => (int) Database::value(
                "SELECT COALESCE(SUM(amount), 0) FROM usertransaction WHERE status LIKE 'MatchWinning#%' AND amount > 0 AND log_entdate >= ?",
                [$since30]
            ),
            'pending_count' => (int) $pending['c'],
            'pending_total' => (int) $pending['total'],
        ];

        $upcoming = Database::all(
            "SELECT matchid, type, map, matchtype, entryfee, winprice, totalplayer, totalplayerjoined, matchstatus, matchschedule
               FROM matchmst
              WHERE matchstatus IN ('upcoming', 'ongoing')
              ORDER BY matchstatus = 'ongoing' DESC, matchschedule ASC
              LIMIT 6"
        );

        $recent = Database::all(
            'SELECT t.trnid, t.userid, t.amount, t.type, t.status, t.log_entdate, u.username
               FROM usertransaction t
               LEFT JOIN `user` u ON u.userid = t.userid
              ORDER BY t.trnid DESC
              LIMIT 8'
        );

        return $this->view('dashboard/index', [
            'title' => 'Dashboard',
            'active' => 'dashboard',
            'stats' => $stats,
            'matchCounts' => $matchCounts,
            'upcoming' => $upcoming,
            'recent' => $recent,
        ]);
    }
}

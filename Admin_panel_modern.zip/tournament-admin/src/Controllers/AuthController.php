<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Core\View;

final class AuthController extends Controller
{
    public function showLogin(Request $request): Response
    {
        if (Auth::check()) {
            return $this->redirect('/');
        }
        if (Auth::adminCount() === 0) {
            return $this->redirect('/setup');
        }
        return Response::html(View::render('auth/login', ['title' => 'Sign in'], 'layouts/auth'));
    }

    public function login(Request $request): Response
    {
        $result = Auth::attempt($request->string('username'), (string) $request->input('password', ''));
        if (!$result['ok']) {
            Session::flashInput(['username' => $request->string('username')]);
            Session::flash('error', (string) $result['error']);
            return Response::redirect(url('/login'));
        }
        $intended = (string) Session::get('intended', '/');
        Session::forget('intended');
        // Only allow same-site relative paths as post-login target.
        if (!str_starts_with($intended, '/') || str_starts_with($intended, '//')) {
            $intended = '/';
        }
        return Response::redirect(url($intended));
    }

    public function logout(Request $request): Response
    {
        Auth::logout();
        Session::start();
        Session::flash('success', 'You have been signed out.');
        return Response::redirect(url('/login'));
    }

    /** One-time creation of the first administrator (only while no admin exists). */
    public function showSetup(Request $request): Response
    {
        if (Auth::adminCount() > 0) {
            return $this->notFound();
        }
        return Response::html(View::render('auth/setup', ['title' => 'Create administrator'], 'layouts/auth'));
    }

    public function setup(Request $request): Response
    {
        if (Auth::adminCount() > 0) {
            return $this->notFound();
        }

        $username = $request->string('username');
        $name = $request->string('display_name');
        $password = (string) $request->input('password', '');
        $confirm = (string) $request->input('confirm_password', '');

        $errors = [];
        if (!preg_match('/^[A-Za-z0-9_.-]{3,40}$/', $username)) {
            $errors['username'] = 'Use 3–40 letters, numbers, dots, dashes or underscores.';
        }
        if ($name === '' || mb_strlen($name) > 100) {
            $errors['display_name'] = 'Display name is required.';
        }
        if (strlen($password) < 10) {
            $errors['password'] = 'Use at least 10 characters.';
        }
        if ($password !== $confirm) {
            $errors['confirm_password'] = 'Passwords do not match.';
        }
        if ($errors) {
            return $this->backWithErrors('/setup', $request, $errors);
        }

        Database::exec(
            'INSERT INTO admins (username, display_name, password_hash, created_at) VALUES (?, ?, ?, ?)',
            [$username, $name, password_hash($password, PASSWORD_DEFAULT), date('Y-m-d H:i:s')]
        );
        Session::flash('success', 'Administrator created. You can sign in now.');
        return Response::redirect(url('/login'));
    }
}

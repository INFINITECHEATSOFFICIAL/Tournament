<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Core\Paginator;
use App\Core\Request;
use App\Core\Response;
use App\Core\Validator;
use App\Services\InsufficientFunds;
use App\Services\Wallet;

final class PlayerController extends Controller
{
    private const SORTS = [
        'newest' => 'u.userid DESC',
        'balance' => 'balance DESC, u.userid DESC',
        'winnings' => 'won DESC, u.userid DESC',
        'played' => 'played DESC, u.userid DESC',
        'name' => 'u.firstname ASC, u.lastname ASC',
    ];

    public function index(Request $request): Response
    {
        $q = $request->string('q');
        $sort = array_key_exists($request->string('sort'), self::SORTS) ? $request->string('sort') : 'newest';

        $where = '1=1';
        $params = [];
        if ($q !== '') {
            $like = '%' . addcslashes($q, '%_\\') . '%';
            $where = '(u.username LIKE ? OR u.firstname LIKE ? OR u.lastname LIKE ? OR u.email LIKE ? OR u.mobile LIKE ? OR u.pubgusername LIKE ? OR u.userid = ?)';
            $params = [$like, $like, $like, $like, $like, $like, ctype_digit($q) ? (int) $q : 0];
        }

        $total = (int) Database::value("SELECT COUNT(*) FROM `user` u WHERE {$where}", $params);
        $pager = new Paginator($total, $request->int('page', 1), 20);

        $players = Database::all(
            "SELECT u.userid, u.firstname, u.lastname, u.username, u.pubgusername, u.email, u.mobile,
                    u.promocode, u.log_entdate,
                    COALESCE(b.balance, 0) AS balance,
                    (SELECT COUNT(*) FROM matchdetail d WHERE d.userid = u.userid) AS played,
                    (SELECT COALESCE(SUM(d.wonamount), 0) FROM matchdetail d WHERE d.userid = u.userid) AS won
               FROM `user` u
               LEFT JOIN userbalance b ON b.userid = u.userid
              WHERE {$where}
              ORDER BY " . self::SORTS[$sort] . $pager->limitSql(),
            $params
        );

        return $this->view('players/index', [
            'title' => 'Players',
            'active' => 'players',
            'players' => $players,
            'pager' => $pager,
            'q' => $q,
            'sort' => $sort,
            'sorts' => array_keys(self::SORTS),
        ]);
    }

    public function show(Request $request, int $id): Response
    {
        $player = Database::one(
            'SELECT u.userid, u.firstname, u.lastname, u.username, u.pubgusername, u.gender, u.email, u.mobile,
                    u.other, u.promocode, u.log_entdate, COALESCE(b.balance, 0) AS balance
               FROM `user` u LEFT JOIN userbalance b ON b.userid = u.userid
              WHERE u.userid = ?',
            [$id]
        );
        if (!$player) {
            return $this->notFound('Player');
        }

        $stats = Database::one(
            'SELECT COUNT(*) AS played, COALESCE(SUM(wonamount), 0) AS won, COALESCE(SUM(kills), 0) AS kills,
                    COALESCE(SUM(won = ?), 0) AS wins
               FROM matchdetail WHERE userid = ?',
            ['Y', $id]
        );

        $matches = Database::all(
            'SELECT d.matchid, d.kills, d.`rank`, d.won, d.wonamount, m.map, m.type, m.matchstatus, m.matchschedule
               FROM matchdetail d JOIN matchmst m ON m.matchid = d.matchid
              WHERE d.userid = ?
              ORDER BY m.matchschedule DESC LIMIT 15',
            [$id]
        );

        $transactions = Database::all(
            'SELECT trnid, amount, type, paytmnumber, status, log_entdate
               FROM usertransaction WHERE userid = ? ORDER BY trnid DESC LIMIT 25',
            [$id]
        );

        return $this->view('players/show', [
            'title' => trim($player['firstname'] . ' ' . $player['lastname']) ?: $player['username'],
            'active' => 'players',
            'player' => $player,
            'stats' => $stats,
            'matches' => $matches,
            'transactions' => $transactions,
        ]);
    }

    /** Manual wallet credit/debit by an administrator (always leaves a ledger entry). */
    public function adjustWallet(Request $request, int $id): Response
    {
        if (!Database::value('SELECT 1 FROM `user` WHERE userid = ?', [$id])) {
            return $this->notFound('Player');
        }

        $v = new Validator($request->post());
        $v->in('direction', 'action', ['credit', 'debit'])
          ->int('amount', 'Amount', 1, 10000000)
          ->string('reason', 'Reason', 3, 150);
        if ($v->fails()) {
            return $this->redirect("/players/{$id}", 'error', implode(' ', $v->errors));
        }

        $amount = (int) $v->clean['amount'];
        $signed = $v->clean['direction'] === 'credit' ? $amount : -$amount;
        $label = ($signed > 0 ? 'AdminCredit: ' : 'AdminDebit: ') . $v->clean['reason'];

        try {
            Wallet::apply($id, $signed, $label);
        } catch (InsufficientFunds) {
            return $this->redirect("/players/{$id}", 'error', 'That debit is larger than the player\'s balance.');
        }
        return $this->redirect("/players/{$id}", 'success', money(abs($signed)) . ($signed > 0 ? ' added to' : ' removed from') . ' the wallet.');
    }
}

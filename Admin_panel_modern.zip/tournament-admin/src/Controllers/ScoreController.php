<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Core\Request;
use App\Core\Response;
use App\Services\InsufficientFunds;
use App\Services\Wallet;

final class ScoreController extends Controller
{
    public function index(Request $request): Response
    {
        // Legacy-style "enter a match id" lookup.
        $lookup = $request->string('match');
        if ($lookup !== '' && ctype_digit($lookup)) {
            return $this->redirect('/scores/' . (int) $lookup);
        }

        $matches = Database::all(
            "SELECT matchid, type, map, matchtype, winprice, perkill, totalplayerjoined, matchstatus, matchschedule
               FROM matchmst
              WHERE matchstatus IN ('ongoing', 'done') OR matchschedule <= ?
              ORDER BY (matchstatus = 'done') ASC, matchschedule DESC
              LIMIT 40",
            [date('Y-m-d H:i:s')]
        );

        return $this->view('scores/index', [
            'title' => 'Score updates',
            'active' => 'scores',
            'matches' => $matches,
            'lookup' => $lookup,
        ]);
    }

    public function show(Request $request, int $id): Response
    {
        $match = Database::one('SELECT * FROM matchmst WHERE matchid = ?', [$id]);
        if (!$match) {
            return $this->notFound('Match');
        }

        $players = Database::all(
            'SELECT d.userid, d.kills, d.`rank`, d.won, d.wonamount, u.username, u.firstname, u.lastname, u.pubgusername
               FROM matchdetail d
               JOIN `user` u ON u.userid = d.userid
              WHERE d.matchid = ?
              ORDER BY d.matchdetailid ASC',
            [$id]
        );

        return $this->view('scores/show', [
            'title' => "Scores · Match #{$id}",
            'active' => 'scores',
            'match' => $match,
            'players' => $players,
        ]);
    }

    /**
     * Save every row at once. Winnings are credited as the *difference* from what was stored,
     * so pressing save twice never pays a player twice (the old panel did).
     */
    public function save(Request $request, int $id): Response
    {
        $match = Database::one('SELECT matchid FROM matchmst WHERE matchid = ?', [$id]);
        if (!$match) {
            return $this->notFound('Match');
        }

        $rows = $request->input('rows', []);
        if (!is_array($rows)) {
            $rows = [];
        }

        $changed = 0;
        try {
            Database::transaction(function () use ($id, $rows, $request, &$changed): void {
                foreach ($rows as $userId => $row) {
                    if (!is_array($row) || !ctype_digit((string) $userId)) {
                        continue;
                    }
                    $userId = (int) $userId;

                    $current = Database::one(
                        'SELECT wonamount, kills, `rank`, won FROM matchdetail WHERE matchid = ? AND userid = ? FOR UPDATE',
                        [$id, $userId]
                    );
                    if (!$current) {
                        continue; // not a participant of this match
                    }

                    $kills = $this->nonNegative($row['kills'] ?? 0, 1000);
                    $amount = $this->nonNegative($row['wonamount'] ?? 0, 100000000);
                    $rankRaw = trim((string) ($row['rank'] ?? ''));
                    $rank = ($rankRaw !== '' && ctype_digit($rankRaw)) ? min((int) $rankRaw, 1000) : null;
                    $won = !empty($row['won']) ? 'Y' : 'N';

                    $same = (int) $current['kills'] === $kills
                        && (int) $current['wonamount'] === $amount
                        && ($current['rank'] === null ? null : (int) $current['rank']) === $rank
                        && $current['won'] === $won;
                    if ($same) {
                        continue;
                    }

                    Database::exec(
                        'UPDATE matchdetail SET kills = ?, `rank` = ?, won = ?, wonamount = ? WHERE matchid = ? AND userid = ?',
                        [$kills, $rank, $won, $amount, $id, $userId]
                    );

                    $delta = $amount - (int) $current['wonamount'];
                    if ($delta !== 0) {
                        Wallet::apply($userId, $delta, ($delta > 0 ? 'MatchWinning#' : 'MatchWinningAdjust#') . $id);
                    }
                    $changed++;
                }

                if ($request->string('mark_done') === '1') {
                    Database::exec("UPDATE matchmst SET matchstatus = 'done' WHERE matchid = ?", [$id]);
                }
            });
        } catch (InsufficientFunds) {
            return $this->redirect("/scores/{$id}", 'error', 'A reduction would take a player\'s wallet below zero. Nothing was saved.');
        }

        $msg = $changed > 0 ? "Saved {$changed} player row(s) for match #{$id}." : 'No changes to save.';
        if ($request->string('mark_done') === '1') {
            $msg .= ' Match marked as completed.';
        }
        return $this->redirect("/scores/{$id}", 'success', $msg);
    }

    private function nonNegative(mixed $value, int $max): int
    {
        $s = trim((string) $value);
        if ($s === '' || !ctype_digit($s)) {
            return 0;
        }
        return min((int) $s, $max);
    }
}

<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database;
use App\Core\Request;
use App\Core\Response;
use App\Core\Session;

final class SettingsController extends Controller
{
    public function index(Request $request): Response
    {
        $version = Database::one('SELECT name, oldversion, newversion FROM appversion LIMIT 1')
            ?? ['name' => 'BattleWorld', 'oldversion' => '1.0', 'newversion' => '1.0'];

        return $this->view('settings/index', [
            'title' => 'Settings',
            'active' => 'settings',
            'version' => $version,
            'admin' => Auth::user(),
            'errors' => Session::errors(),
        ]);
    }

    public function changePassword(Request $request): Response
    {
        $admin = Auth::user();
        $current = (string) $request->input('current_password', '');
        $new = (string) $request->input('new_password', '');
        $confirm = (string) $request->input('confirm_password', '');

        $row = Database::one('SELECT password_hash FROM admins WHERE id = ?', [$admin['id']]);
        $errors = [];
        if (!$row || !password_verify($current, $row['password_hash'])) {
            $errors['current_password'] = 'Current password is incorrect.';
        }
        if (strlen($new) < 10) {
            $errors['new_password'] = 'Use at least 10 characters.';
        }
        if ($new !== $confirm) {
            $errors['confirm_password'] = 'Passwords do not match.';
        }
        if ($errors) {
            return $this->backWithErrors('/settings', $request, $errors);
        }

        Database::exec('UPDATE admins SET password_hash = ? WHERE id = ?', [password_hash($new, PASSWORD_DEFAULT), $admin['id']]);
        Session::regenerate();
        return $this->redirect('/settings', 'success', 'Password changed.');
    }

    public function updateVersion(Request $request): Response
    {
        $old = $request->string('oldversion');
        $new = $request->string('newversion');
        $pattern = '/^[0-9A-Za-z.\-]{1,20}$/';
        if (!preg_match($pattern, $old) || !preg_match($pattern, $new)) {
            return $this->redirect('/settings', 'error', 'Versions may only contain letters, numbers, dots and dashes.');
        }
        Database::exec(
            "INSERT INTO appversion (name, oldversion, newversion) VALUES ('BattleWorld', ?, ?)
             ON DUPLICATE KEY UPDATE oldversion = VALUES(oldversion), newversion = VALUES(newversion)",
            [$old, $new]
        );
        return $this->redirect('/settings', 'success', 'App version saved.');
    }
}

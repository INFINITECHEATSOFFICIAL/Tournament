<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Core\Request;
use App\Core\Response;

/** Game rules shown in the app. remarkid = "basic" (all matches) or a match id. */
final class RuleController extends Controller
{
    public function index(Request $request): Response
    {
        $rules = Database::all('SELECT rulesid, rules, remarkid FROM rules ORDER BY remarkid = \'basic\' DESC, remarkid, rulesid');
        return $this->view('rules/index', ['title' => 'Rules', 'active' => 'rules', 'rules' => $rules]);
    }

    public function store(Request $request): Response
    {
        [$text, $remark, $error] = $this->read($request);
        if ($error) {
            return $this->redirect('/rules', 'error', $error);
        }
        Database::exec('INSERT INTO rules (rules, remarkid) VALUES (?, ?)', [$text, $remark]);
        return $this->redirect('/rules', 'success', 'Rule added.');
    }

    public function update(Request $request, int $id): Response
    {
        [$text, $remark, $error] = $this->read($request);
        if ($error) {
            return $this->redirect('/rules', 'error', $error);
        }
        Database::exec('UPDATE rules SET rules = ?, remarkid = ? WHERE rulesid = ?', [$text, $remark, $id]);
        return $this->redirect('/rules', 'success', 'Rule saved.');
    }

    public function destroy(Request $request, int $id): Response
    {
        Database::exec('DELETE FROM rules WHERE rulesid = ?', [$id]);
        return $this->redirect('/rules', 'success', 'Rule deleted.');
    }

    /** @return array{0:string,1:string,2:?string} */
    private function read(Request $request): array
    {
        $text = $request->string('rules');
        $remark = strtolower($request->string('remarkid', 'basic')) ?: 'basic';
        if ($text === '' || mb_strlen($text) > 500) {
            return ['', '', 'A rule must be 1–500 characters.'];
        }
        if ($remark !== 'basic' && !ctype_digit($remark)) {
            return ['', '', 'Applies-to must be "basic" or a match ID.'];
        }
        return [$text, $remark, null];
    }
}

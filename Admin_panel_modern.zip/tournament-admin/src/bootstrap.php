<?php

declare(strict_types=1);

define('BASE_PATH', dirname(__DIR__));

// Minimal PSR-4 autoloader – no Composer needed (works on any shared host).
spl_autoload_register(static function (string $class): void {
    $prefix = 'App\\';
    if (strncmp($class, $prefix, strlen($prefix)) !== 0) {
        return;
    }
    $file = BASE_PATH . '/src/' . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
    if (is_file($file)) {
        require $file;
    }
});

require BASE_PATH . '/src/helpers.php';

App\Core\Env::load(BASE_PATH . '/.env');

date_default_timezone_set(env('APP_TIMEZONE', 'Asia/Kolkata') ?? 'Asia/Kolkata');
mb_internal_encoding('UTF-8');

$debug = filter_var(env('APP_DEBUG', 'false'), FILTER_VALIDATE_BOOLEAN);
error_reporting(E_ALL);
ini_set('display_errors', $debug ? '1' : '0');
ini_set('log_errors', '1');
ini_set('error_log', BASE_PATH . '/storage/logs/php-error.log');

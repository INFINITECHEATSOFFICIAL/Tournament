<?php

declare(strict_types=1);

use App\Core\Env;
use App\Core\Request;
use App\Core\Session;

/** Read a configuration value from .env / the process environment. */
function env(string $key, ?string $default = null): ?string
{
    return Env::get($key, $default);
}

/** HTML-escape anything before printing it. */
function e(mixed $value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** Build an application URL (respects sub-folder installs). */
function url(string $path = '/', array $query = []): string
{
    $url = Request::basePath() . '/' . ltrim($path, '/');
    $query = array_filter($query, static fn ($v) => $v !== null && $v !== '');
    if ($query) {
        $url .= '?' . http_build_query($query);
    }
    return $url;
}

/** URL of a static asset with a cache-busting version. */
function asset(string $path): string
{
    $file = BASE_PATH . '/public/assets/' . ltrim($path, '/');
    $version = is_file($file) ? (string) filemtime($file) : '1';
    return url('assets/' . ltrim($path, '/')) . '?v=' . $version;
}

/** URL of an uploaded media file. */
function media_url(?string $file, string $folder = ''): string
{
    $file = (string) $file;
    $rel = 'uploads/matchimg/' . ($folder !== '' ? trim($folder, '/') . '/' : '') . rawurlencode($file);
    return url($rel);
}

function money(int|float|string|null $amount): string
{
    $symbol = env('CURRENCY_SYMBOL', '₹') ?? '₹';
    $n = (float) ($amount ?? 0);
    $formatted = number_format(abs($n), 0, '.', ',');
    return ($n < 0 ? '-' : '') . $symbol . $formatted;
}

function fmt_dt(?string $value, string $format = 'd M Y, h:i A'): string
{
    if ($value === null || $value === '' || str_starts_with($value, '0000')) {
        return '—';
    }
    $ts = strtotime($value);
    return $ts === false ? e($value) : date($format, $ts);
}

function csrf_field(): string
{
    return '<input type="hidden" name="_token" value="' . e(Session::csrfToken()) . '">';
}

/** Previously submitted form value (after a validation error). */
function old(string $key, mixed $default = ''): mixed
{
    return Session::old($key, $default);
}

/** Inline SVG icon from the sprite defined in the layout. */
function icon(string $name, string $class = 'icon'): string
{
    return '<svg class="' . e($class) . '" aria-hidden="true"><use href="#i-' . e($name) . '"></use></svg>';
}

/** CSS class for the active sidebar item. */
function nav_active(string $current, string ...$keys): string
{
    return in_array($current, $keys, true) ? ' is-active' : '';
}

/** Coloured badge for a match status / generic state. */
function badge(string $label, string $tone = 'neutral'): string
{
    return '<span class="badge badge-' . e($tone) . '">' . e($label) . '</span>';
}

function match_status_badge(?string $status): string
{
    return match (strtolower((string) $status)) {
        'upcoming' => badge('Upcoming', 'info'),
        'ongoing' => badge('Live', 'success'),
        'done' => badge('Completed', 'neutral'),
        default => badge((string) $status ?: 'Unknown', 'warn'),
    };
}

/** Render a partial template without a layout. */
function partial(string $template, array $data = []): string
{
    return App\Core\View::partial($template, $data);
}

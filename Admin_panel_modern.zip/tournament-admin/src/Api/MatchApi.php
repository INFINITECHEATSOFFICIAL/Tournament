<?php

declare(strict_types=1);

namespace App\Api;

use App\Core\Database;

final class MatchApi
{
    /**
     * Match list rows. Room id / password are only revealed to players who joined that match
     * (the old API leaked them to everybody).
     */
    private function matchesFor(int $userId, string $status, string $order): array
    {
        $allowed = ['upcoming', 'ongoing', 'done'];
        if (!in_array($status, $allowed, true)) {
            return [];
        }
        $orderSql = $order === 'desc' ? 'mst.matchschedule DESC' : 'mst.matchschedule ASC';
        return Database::all(
            "SELECT mst.matchid,
                    CASE WHEN dtl.userid IS NULL THEN NULL ELSE mst.roomid END AS roomid,
                    CASE WHEN dtl.userid IS NULL THEN NULL ELSE mst.roompassword END AS roompassword,
                    mst.type, mst.version, mst.map, mst.maintopbannerimg, mst.iconimg, mst.matchtype, mst.totalplayer,
                    mst.totalplayerjoined, mst.entryfee, mst.winprice, mst.perkill, mst.joinstatus, mst.matchstatus,
                    mst.matchschedule, mst.log_entdate, dtl.userid,
                    (CASE WHEN dtl.userid IS NULL THEN '0' ELSE '1' END) AS playerjoinstatus
               FROM matchmst mst
               LEFT JOIN matchdetail dtl ON dtl.matchid = mst.matchid AND dtl.userid = ?
              WHERE mst.matchstatus = ?
              ORDER BY {$orderSql}",
            [$userId, $status]
        );
    }

    private function requireUser(): int
    {
        if (!Api::has('userid')) {
            Api::missing();
        }
        $userId = (int) Api::input('userid');
        if (!Api::userExists($userId)) {
            Api::fail("Userid({$userId}) is not valid.", 2);
        }
        return $userId;
    }

    public function upcoming(): void
    {
        $userId = $this->requireUser();
        $extra = [
            'rajanruser' => [Api::profile('ur.userid = ?', [$userId])],
            'rajanr' => $this->matchesFor($userId, 'upcoming', 'asc'),
        ];
        Api::ok('Get all match succsessfully done.', $extra);
    }

    public function ongoing(): void
    {
        $userId = $this->requireUser();
        Api::ok('Get all match succsessfully done.', ['rajanr' => $this->matchesFor($userId, 'ongoing', 'asc')]);
    }

    public function results(): void
    {
        $userId = $this->requireUser();
        Api::ok('Get all result succsessfully done.', ['rajanr' => $this->matchesFor($userId, 'done', 'desc')]);
    }

    public function details(): void
    {
        if (!Api::has('matchid', 'userid')) {
            Api::missing();
        }
        $matchId = (int) Api::input('matchid');
        $userId = (int) Api::input('userid');

        $match = Database::one(
            'SELECT matchid, roomid, roompassword, type, version, map, maintopbannerimg, iconimg, matchtype, totalplayer,
                    totalplayerjoined, entryfee, winprice, perkill, joinstatus, matchstatus, matchschedule, log_entdate
               FROM matchmst WHERE matchid = ?',
            [$matchId]
        );
        if (!$match) {
            Api::fail('Match not found.', 2);
        }

        $joined = (bool) Database::value('SELECT 1 FROM matchdetail WHERE matchid = ? AND userid = ?', [$matchId, $userId]);
        if (!$joined) {
            $match['roomid'] = null;
            $match['roompassword'] = null;
        }
        $rules = Database::all("SELECT rules FROM rules WHERE remarkid IN (?, 'basic')", [(string) $matchId]);

        Api::ok('Get all match succsessfully done.', [
            'playerjoinstatus' => $joined ? '1' : '0',
            'rules' => $rules,
            'rajanr' => [$match],
        ]);
    }

    public function participants(): void
    {
        if (!Api::has('username', 'matchid')) {
            Api::missing();
        }
        $rows = Database::all(
            'SELECT mst.matchid, mst.type, mst.version, mst.map, mst.matchtype, mst.totalplayer, mst.totalplayerjoined,
                    mst.entryfee, mst.winprice, mst.perkill, mst.joinstatus, mst.matchstatus, mst.matchschedule,
                    dtl.userid, dtl.wonamount, dtl.kills, dtl.`rank`, dtl.won, ur.firstname, ur.lastname, ur.username
               FROM matchmst mst
               JOIN matchdetail dtl ON dtl.matchid = mst.matchid
               JOIN `user` ur ON ur.userid = dtl.userid
              WHERE mst.matchid = ?',
            [(int) Api::input('matchid')]
        );
        Api::ok('Signin succsessfully done.', ['rajanr' => $rows]);
    }

    public function resultDetails(): void
    {
        if (!Api::has('matchid', 'userid')) {
            Api::missing();
        }
        $matchId = (int) Api::input('matchid');

        $select = 'SELECT mst.matchid, mst.type, mst.version, mst.map, mst.matchtype, mst.totalplayer, mst.totalplayerjoined,
                          mst.entryfee, mst.winprice, mst.perkill, mst.joinstatus, mst.matchstatus, mst.matchschedule,
                          dtl.userid, dtl.wonamount, dtl.kills, dtl.`rank`, dtl.won, ur.firstname, ur.lastname, ur.username
                     FROM matchmst mst
                     JOIN matchdetail dtl ON dtl.matchid = mst.matchid
                     JOIN `user` ur ON ur.userid = dtl.userid
                    WHERE mst.matchid = ?';

        $all = Database::all($select . ' ORDER BY dtl.wonamount DESC, dtl.kills DESC, dtl.userid ASC', [$matchId]);
        $winners = [];
        foreach ($all as $i => &$row) {
            $row['playerrrank'] = (string) ($i + 1); // rank by winnings, as before
        }
        unset($row);
        foreach ($all as $row) {
            if ($row['won'] === 'Y') {
                $winners[] = $row;
            }
        }
        foreach ($winners as $i => &$w) {
            $w['playerrrank'] = (string) ($i + 1);
        }
        unset($w);

        Api::ok('Get all match succsessfully done.', ['rajanrwon' => $winners, 'rajanr' => $all]);
    }

    public function rules(): void
    {
        $rules = Database::all('SELECT rulesid, rules, remarkid FROM rules ORDER BY rulesid');
        Api::ok('Rules get succsessfully done.', ['rajanr' => $rules]);
    }

    public function topPlayers(): void
    {
        if (!Api::has('userid')) {
            Api::missing();
        }
        $rows = Database::all(
            'SELECT dtl.userid, ur.firstname, ur.lastname, SUM(dtl.wonamount) AS wonamount
               FROM matchdetail dtl JOIN `user` ur ON ur.userid = dtl.userid
              GROUP BY dtl.userid, ur.firstname, ur.lastname
              ORDER BY SUM(dtl.wonamount) DESC, dtl.userid ASC
              LIMIT 25'
        );
        foreach ($rows as $i => &$r) {
            $r['playerrrank'] = (string) ($i + 1);
        }
        unset($r);
        Api::ok('Get all match succsessfully done.', ['rajanr' => $rows]);
    }
}

<?php

declare(strict_types=1);

namespace App\Api;

use App\Core\Database;
use App\Services\Instamojo;

final class MetaApi
{
    /** Returns the real latest app version (the old script always answered "1.0"). */
    public function appUpdater(): void
    {
        if (!Api::has('userid')) {
            Api::missing();
        }
        $row = Database::one('SELECT name, oldversion, newversion FROM appversion LIMIT 1');
        if (!$row) {
            Api::fail('Oops! An error occurred.');
        }
        Api::ok('Product successfully created.', ['newversion' => $row['newversion'], 'oldversion' => $row['oldversion']]);
    }

    /** Plain-text Instamojo token ("production<token>"), exactly like the old access_token.php. */
    public function instamojoToken(): void
    {
        header('Content-Type: text/plain; charset=UTF-8');
        $im = new Instamojo();
        $token = $im->accessToken();
        echo $token === null ? 'Error: unable to get token' : $im->envName() . $token;
        exit;
    }
}

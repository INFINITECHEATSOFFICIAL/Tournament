<?php

declare(strict_types=1);

namespace App\Api;

use App\Core\Database;

/**
 * Shared plumbing for the mobile-app endpoints.
 *
 * Response shapes (success / message / "rajanr" arrays, values as strings) are kept
 * identical to the legacy scripts so the existing Android app keeps working.
 */
final class Api
{
    public static function boot(): void
    {
        Database::stringifyFetches(true);
        header('Content-Type: application/json; charset=UTF-8');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: no-store');

        set_exception_handler(static function (\Throwable $e): void {
            error_log((string) $e);
            http_response_code(200); // legacy app only looks at the JSON body
            echo json_encode(['success' => 0, 'message' => 'Oops! An error occurred.']);
        });
    }

    /** Request value (GET or POST – the legacy app used $_REQUEST). */
    public static function input(string $key): ?string
    {
        $v = $_REQUEST[$key] ?? null;
        return is_string($v) ? trim($v) : null;
    }

    public static function has(string ...$keys): bool
    {
        foreach ($keys as $k) {
            if (!isset($_REQUEST[$k]) || !is_string($_REQUEST[$k])) {
                return false;
            }
        }
        return true;
    }

    public static function respond(array $data): never
    {
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR);
        exit;
    }

    public static function missing(): never
    {
        self::respond(['success' => 0, 'message' => 'Required field(s) is missing']);
    }

    public static function fail(string $message = 'Oops! An error occurred.', int $code = 0): never
    {
        self::respond(['success' => $code, 'message' => $message]);
    }

    public static function ok(string $message, array $extra = []): never
    {
        self::respond(['success' => 1, 'message' => $message] + $extra);
    }

    /** Verify a password against a bcrypt hash OR a legacy plain-text value. */
    public static function verifyPassword(string $plain, string $stored): bool
    {
        if (password_get_info($stored)['algo'] !== null) {
            return password_verify($plain, $stored);
        }
        return hash_equals($stored, $plain); // legacy plain-text row – upgraded on next login
    }

    /** Fetch the user row used by sign-in / profile responses (without any password data). */
    public static function profile(string $where, array $params): array
    {
        $row = Database::one(
            "SELECT ur.userid, ur.firstname, ur.lastname, ur.username, ur.pubgusername, ur.gender, ur.email, ur.mobile,
                    '' AS password, ur.other, ur.promocode,
                    COALESCE(bal.balance, 0) AS balance,
                    COUNT(md.matchid) AS totalmatchplayed,
                    COALESCE(SUM(md.wonamount), 0) AS wonamount,
                    COALESCE(SUM(md.kills), 0) AS kills
               FROM `user` ur
               LEFT JOIN userbalance bal ON bal.userid = ur.userid
               LEFT JOIN matchdetail md ON md.userid = ur.userid
              WHERE {$where}
              GROUP BY ur.userid, ur.firstname, ur.lastname, ur.username, ur.pubgusername, ur.gender, ur.email,
                       ur.mobile, ur.other, ur.promocode, bal.balance",
            $params
        );
        return $row ?? [];
    }

    public static function userExists(int $userId): bool
    {
        return (bool) Database::value('SELECT 1 FROM `user` WHERE userid = ?', [$userId]);
    }
}

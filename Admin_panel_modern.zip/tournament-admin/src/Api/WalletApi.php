<?php

declare(strict_types=1);

namespace App\Api;

use App\Core\Database;
use App\Services\InsufficientFunds;
use App\Services\Instamojo;
use App\Services\Wallet;
use App\Support\WithdrawalState;

final class WalletApi
{
    public function transactions(): void
    {
        if (!Api::has('userid')) {
            Api::missing();
        }
        $userId = (int) Api::input('userid');
        if (!Api::userExists($userId)) {
            Api::fail('Userid is not valid.', 2);
        }
        $rows = Database::all(
            'SELECT trnid, userid, amount, type, paytmnumber, status, log_entdate
               FROM usertransaction WHERE userid = ? ORDER BY log_entdate DESC, trnid DESC',
            [$userId]
        );
        Api::ok('Signin succsessfully done.', ['rajanr' => $rows]);
    }

    /**
     * Join a match. Entry fee, status and capacity are read from the database –
     * the old endpoint trusted the fee sent by the phone (so it could be set to 0).
     * The `entryfee` field is still accepted, but ignored.
     */
    public function join(): void
    {
        if (!Api::has('userid', 'matchid', 'entryfee')) {
            Api::missing();
        }
        $userId = (int) Api::input('userid');
        $matchId = (int) Api::input('matchid');

        try {
            Database::transaction(function () use ($userId, $matchId): void {
                $match = Database::one(
                    'SELECT matchid, matchstatus, matchtype, entryfee, totalplayer, totalplayerjoined FROM matchmst WHERE matchid = ? FOR UPDATE',
                    [$matchId]
                );
                if (!$match || !Api::userExists($userId)) {
                    throw new \DomainException('Match or user not found.');
                }
                if ($match['matchstatus'] !== 'upcoming') {
                    throw new \DomainException('This match is no longer open for joining.');
                }
                if ((int) $match['totalplayerjoined'] >= (int) $match['totalplayer']) {
                    throw new \DomainException('This match is full.');
                }
                if (Database::value('SELECT 1 FROM matchdetail WHERE matchid = ? AND userid = ?', [$matchId, $userId])) {
                    throw new \DomainException('You have already joined this match.');
                }

                Database::exec(
                    "INSERT INTO matchdetail (matchid, userid, wonamount, kills, `rank`, won, log_entdate) VALUES (?, ?, 0, 0, NULL, 'N', ?)",
                    [$matchId, $userId, date('Y-m-d H:i:s')]
                );
                Database::exec('UPDATE matchmst SET totalplayerjoined = totalplayerjoined + 1 WHERE matchid = ?', [$matchId]);

                $fee = strtolower((string) $match['matchtype']) === 'free' ? 0 : (int) $match['entryfee'];
                if ($fee > 0) {
                    Wallet::apply($userId, -$fee, 'JoinMatch#' . $matchId);
                }
            });
        } catch (InsufficientFunds) {
            Api::fail('Insufficient balance. Please add money to your wallet.');
        } catch (\DomainException $e) {
            Api::fail($e->getMessage());
        }
        Api::ok('Product successfully created.');
    }

    /** Add money after an Instamojo payment. The payment is verified server-side before crediting. */
    public function payment(): void
    {
        if (!Api::has('userid', 'addamount', 'instaorderid', 'instatxnid', 'instapaymentid', 'instatoken', 'status')) {
            Api::missing();
        }
        $userId = (int) Api::input('userid');
        $claimed = (int) round((float) Api::input('addamount'));
        $paymentId = (string) Api::input('instapaymentid');

        if ($claimed <= 0 || $paymentId === '' || !Api::userExists($userId)) {
            Api::fail('Invalid payment details.');
        }

        // Idempotent: the app may retry – never credit one payment twice.
        if (Database::value('SELECT 1 FROM usertransaction WHERE instapaymentid = ?', [$paymentId])) {
            Api::ok('Payment already recorded.');
        }

        $mode = strtolower(env('PAYMENT_VERIFY_MODE', 'instamojo') ?? 'instamojo');
        $amount = $claimed;
        if ($mode === 'disabled') {
            Api::fail('Adding money is temporarily unavailable.');
        } elseif ($mode === 'instamojo') {
            $verified = (new Instamojo())->verifyPayment($paymentId);
            if ($verified === null || $verified !== $claimed) {
                error_log("Payment verification failed for {$paymentId} (claimed {$claimed}, verified " . var_export($verified, true) . ')');
                Api::fail('We could not verify this payment. If money was deducted it will be reviewed by support.');
            }
            $amount = $verified;
        } // 'trust' = legacy behaviour (insecure)

        $remark = mb_substr((string) Api::input('status'), 0, 200);
        try {
            Wallet::apply($userId, $amount, $remark !== '' ? $remark : 'Money added', [
                'instaorderid' => mb_substr((string) Api::input('instaorderid'), 0, 250),
                'instatxnid' => mb_substr((string) Api::input('instatxnid'), 0, 250),
                'instapaymentid' => $paymentId,
                'instatoken' => mb_substr((string) Api::input('instatoken'), 0, 250),
            ]);
        } catch (\PDOException $e) {
            // Unique key on instapaymentid: a parallel retry won the race.
            if ($e->getCode() === '23000') {
                Api::ok('Payment already recorded.');
            }
            throw $e;
        }
        Api::ok('Product successfully created.');
    }

    /** Withdrawal request: the amount is taken from the wallet immediately and refunded if the admin rejects it. */
    public function withdraw(): void
    {
        if (!Api::has('userid', 'paytmnumber', 'withdrawamount', 'status')) {
            Api::missing();
        }
        $userId = (int) Api::input('userid');
        $amount = abs((int) round((float) Api::input('withdrawamount'))); // legacy app may send a negative number
        $paytm = mb_substr((string) Api::input('paytmnumber'), 0, 100);

        if ($amount <= 0 || $paytm === '' || !Api::userExists($userId)) {
            Api::fail('Invalid withdrawal details.');
        }
        try {
            Wallet::apply($userId, -$amount, WithdrawalState::LABEL_PENDING, ['paytmnumber' => $paytm]);
        } catch (InsufficientFunds) {
            Api::fail('Insufficient balance.');
        }
        Api::ok('Product successfully created.');
    }
}

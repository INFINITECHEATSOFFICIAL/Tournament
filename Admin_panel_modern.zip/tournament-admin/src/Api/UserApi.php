<?php

declare(strict_types=1);

namespace App\Api;

use App\Core\Database;
use App\Core\RateLimiter;
use App\Core\Request;

final class UserApi
{
    public function signIn(): void
    {
        if (!Api::has('username', 'password')) {
            Api::missing();
        }
        $username = (string) Api::input('username');
        $password = (string) $_REQUEST['password'];
        $ip = Request::ip();

        if (RateLimiter::tooMany('api', mb_strtolower($username), $ip, 10, 100, 15)) {
            Api::fail('Too many attempts. Please try again in a few minutes.', 2);
        }

        $user = Database::one('SELECT userid, password FROM `user` WHERE username = ?', [$username]);
        if (!$user || !Api::verifyPassword($password, (string) $user['password'])) {
            RateLimiter::hit('api', mb_strtolower($username), $ip);
            Api::fail('Username or password is not valid.', 2);
        }
        RateLimiter::clear('api', mb_strtolower($username));

        // Transparent upgrade of legacy plain-text passwords.
        if (password_get_info((string) $user['password'])['algo'] === null || password_needs_rehash((string) $user['password'], PASSWORD_DEFAULT)) {
            Database::exec('UPDATE `user` SET password = ? WHERE userid = ?', [password_hash($password, PASSWORD_DEFAULT), $user['userid']]);
        }

        $profile = Api::profile('ur.userid = ?', [$user['userid']]);
        Api::ok('Signin succsessfully done.', ['rajanr' => [$profile]]);
    }

    public function create(): void
    {
        if (!Api::has('firstname', 'lastname', 'username', 'pubgusername', 'email', 'mobile', 'password', 'other', 'promocode')) {
            Api::missing();
        }
        $f = [];
        foreach (['firstname', 'lastname', 'username', 'pubgusername', 'email', 'mobile', 'other', 'promocode'] as $k) {
            $f[$k] = (string) Api::input($k);
        }
        $password = (string) $_REQUEST['password'];

        if ($f['firstname'] === '' || $f['username'] === '' || $f['mobile'] === '' || strlen($password) < 4
            || !filter_var($f['email'], FILTER_VALIDATE_EMAIL)
            || mb_strlen($f['username']) > 200 || mb_strlen($f['email']) > 200) {
            Api::fail('Please check the details you entered.');
        }

        if (RateLimiter::tooMany('api-signup', 'signup', Request::ip(), 1000, 20, 60)) {
            Api::fail('Too many sign-ups from this network. Please try later.');
        }

        $dupe = Database::one(
            'SELECT mobile, email, username FROM `user` WHERE mobile = ? OR email = ? OR username = ? LIMIT 1',
            [$f['mobile'], $f['email'], $f['username']]
        );
        if ($dupe) {
            if ($dupe['mobile'] === $f['mobile']) {
                Api::fail('mobile is same.', 2);
            }
            if (strcasecmp($dupe['email'], $f['email']) === 0) {
                Api::fail('email is same.', 2);
            }
            Api::fail('username is same.', 2);
        }

        RateLimiter::hit('api-signup', 'signup', Request::ip());

        Database::transaction(function () use ($f, $password): void {
            $userId = Database::insert(
                'INSERT INTO `user` (firstname, lastname, username, pubgusername, gender, email, mobile, password, other, promocode, log_entdate)
                 VALUES (?, ?, ?, ?, NULL, ?, ?, ?, ?, ?, ?)',
                [
                    $f['firstname'], $f['lastname'], $f['username'], $f['pubgusername'], $f['email'], $f['mobile'],
                    password_hash($password, PASSWORD_DEFAULT), $f['other'],
                    $f['promocode'] === '' ? null : $f['promocode'], date('Y-m-d H:i:s'),
                ]
            );
            // Same sign-up bonus the old database trigger gave: 5 when a promo code is supplied.
            Database::exec(
                'INSERT INTO userbalance (userid, balance, log_entdate) VALUES (?, ?, ?)',
                [$userId, $f['promocode'] === '' ? 0 : 5, date('Y-m-d H:i:s')]
            );
        });

        Api::ok('Product successfully created.');
    }

    public function editProfile(): void
    {
        if (!Api::has('userid', 'username', 'pubgusername', 'firstname', 'lastname', 'mobile')) {
            Api::missing();
        }
        $userId = (int) Api::input('userid');
        $username = (string) Api::input('username');
        $mobile = (string) Api::input('mobile');

        if ($mobile === '' || Database::value('SELECT 1 FROM `user` WHERE mobile = ? AND userid <> ?', [$mobile, $userId])) {
            Api::fail('mobile is same.', 2);
        }

        $changed = Database::exec(
            'UPDATE `user` SET firstname = ?, lastname = ?, pubgusername = ?, mobile = ? WHERE username = ? AND userid = ?',
            [Api::input('firstname'), Api::input('lastname'), Api::input('pubgusername'), $mobile, $username, $userId]
        );
        $profile = Api::profile('ur.username = ? AND ur.userid = ?', [$username, $userId]);
        if (!$profile) {
            Api::fail('User is not valid.', 2);
        }
        unset($changed);
        Api::ok('Signin succsessfully done.', ['rajanr' => [$profile]]);
    }

    public function resetPassword(): void
    {
        if (!Api::has('userid', 'password', 'oldpassword')) {
            Api::missing();
        }
        $userId = (int) Api::input('userid');
        $new = (string) $_REQUEST['password'];
        $old = (string) $_REQUEST['oldpassword'];

        if (RateLimiter::tooMany('api', 'reset:' . $userId, Request::ip(), 10, 100, 15)) {
            Api::fail('Too many attempts. Please try again in a few minutes.', 2);
        }
        $row = Database::one('SELECT password FROM `user` WHERE userid = ?', [$userId]);
        if (!$row || !Api::verifyPassword($old, (string) $row['password'])) {
            RateLimiter::hit('api', 'reset:' . $userId, Request::ip());
            Api::fail('password is wrong', 2);
        }
        if (strlen($new) < 4) {
            Api::fail('New password is too short.');
        }
        Database::exec('UPDATE `user` SET password = ? WHERE userid = ?', [password_hash($new, PASSWORD_DEFAULT), $userId]);
        Api::ok('Product successfully created.');
    }
}

<?php

declare(strict_types=1);

namespace App\Services;

/**
 * Minimal Instamojo client (OAuth2 client-credentials + payment lookup).
 * Credentials come from .env – never hard-code them.
 */
final class Instamojo
{
    private string $clientId;
    private string $clientSecret;
    private string $base;
    private string $envName;

    public function __construct()
    {
        $this->clientId = env('INSTAMOJO_CLIENT_ID', '') ?? '';
        $this->clientSecret = env('INSTAMOJO_CLIENT_SECRET', '') ?? '';
        $test = str_starts_with($this->clientId, 'test_');
        $this->base = $test ? 'https://test.instamojo.com' : 'https://api.instamojo.com';
        $this->envName = $test ? 'test' : 'production';
    }

    public function envName(): string
    {
        return $this->envName;
    }

    public function accessToken(): ?string
    {
        if ($this->clientId === '' || $this->clientSecret === '') {
            return null;
        }
        $res = $this->request('POST', $this->base . '/oauth2/token/', [
            'client_id' => $this->clientId,
            'client_secret' => $this->clientSecret,
            'grant_type' => 'client_credentials',
        ]);
        return is_array($res) && !empty($res['access_token']) ? (string) $res['access_token'] : null;
    }

    /**
     * Ask Instamojo whether a payment really succeeded.
     *
     * @return int|null amount in whole rupees when the payment is successful, otherwise null
     */
    public function verifyPayment(string $paymentId): ?int
    {
        $token = $this->accessToken();
        if ($token === null || !preg_match('/^[A-Za-z0-9_-]{5,100}$/', $paymentId)) {
            return null;
        }
        $res = $this->request('GET', $this->base . '/v2/payments/' . rawurlencode($paymentId) . '/', null, $token);
        if (!is_array($res)) {
            return null;
        }

        $status = $res['status'] ?? null;
        $success = $status === true
            || (is_string($status) && in_array(strtolower($status), ['credit', 'success', 'successful', 'completed'], true));
        if (!$success || !isset($res['amount']) || !is_numeric($res['amount'])) {
            return null;
        }
        return (int) round((float) $res['amount']);
    }

    private function request(string $method, string $url, ?array $fields, ?string $bearer = null): ?array
    {
        $ch = curl_init($url);
        $headers = ['Accept: application/json'];
        if ($bearer !== null) {
            $headers[] = 'Authorization: Bearer ' . $bearer;
        }
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_HTTPHEADER => $headers,
        ]);
        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($fields ?? []));
        }
        $body = curl_exec($ch);
        $err = curl_errno($ch);
        curl_close($ch);

        if ($err !== 0 || !is_string($body)) {
            return null;
        }
        $json = json_decode($body, true);
        return is_array($json) ? $json : null;
    }
}

<?php

declare(strict_types=1);

namespace App\Services;

use App\Core\Database;

/** File-system helpers for match banners / icons / lottie JSON in /public/uploads/matchimg. */
final class Media
{
    public const IMAGE_EXT = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
    public const MAX_BYTES = 5_242_880; // 5 MB

    public static function dir(string $sub = ''): string
    {
        $base = BASE_PATH . '/public/uploads/matchimg';
        return $sub === '' ? $base : $base . '/' . trim($sub, '/');
    }

    /** @return list<string> image file names that can be picked on a match */
    public static function images(): array
    {
        return self::scan(self::dir(), self::IMAGE_EXT);
    }

    /** @return list<string> lottie animation files uploaded for the app */
    public static function animations(): array
    {
        return self::scan(self::dir('images'), ['json']);
    }

    /** @return list<string> */
    private static function scan(string $dir, array $exts): array
    {
        if (!is_dir($dir)) {
            return [];
        }
        $out = [];
        foreach (scandir($dir) ?: [] as $f) {
            if ($f[0] === '.' || !is_file($dir . '/' . $f)) {
                continue;
            }
            if (in_array(strtolower(pathinfo($f, PATHINFO_EXTENSION)), $exts, true)) {
                $out[] = $f;
            }
        }
        sort($out, SORT_NATURAL | SORT_FLAG_CASE);
        return $out;
    }

    public static function usageCount(string $file): int
    {
        return (int) Database::value(
            'SELECT COUNT(*) FROM matchmst WHERE maintopbannerimg = ? OR iconimg = ?',
            [$file, $file]
        );
    }

    public static function safeName(string $original): string
    {
        $name = basename(str_replace('\\', '/', $original));
        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        $stem = pathinfo($name, PATHINFO_FILENAME);
        $stem = trim((string) preg_replace('/[^A-Za-z0-9_-]+/', '-', $stem), '-');
        if ($stem === '') {
            $stem = 'file';
        }
        return mb_substr($stem, 0, 80) . '.' . $ext;
    }

    /**
     * Validate and store an uploaded file.
     *
     * @return array{ok:bool,message:string,name?:string}
     */
    public static function store(array $file): array
    {
        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            return ['ok' => false, 'message' => 'Upload failed (error code ' . (int) ($file['error'] ?? -1) . ').'];
        }
        if (($file['size'] ?? 0) > self::MAX_BYTES) {
            return ['ok' => false, 'message' => 'File is larger than 5 MB.'];
        }
        if (!is_uploaded_file($file['tmp_name'])) {
            return ['ok' => false, 'message' => 'Invalid upload.'];
        }

        $name = self::safeName((string) $file['name']);
        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));

        if (in_array($ext, self::IMAGE_EXT, true)) {
            $mime = (new \finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
            $okMime = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
            if (!in_array($mime, $okMime, true) || @getimagesize($file['tmp_name']) === false) {
                return ['ok' => false, 'message' => 'That file is not a valid image.'];
            }
            $target = self::dir();
        } elseif ($ext === 'json') {
            json_decode((string) file_get_contents($file['tmp_name']));
            if (json_last_error() !== JSON_ERROR_NONE) {
                return ['ok' => false, 'message' => 'That file is not valid JSON.'];
            }
            $target = self::dir('images');
        } else {
            return ['ok' => false, 'message' => 'Allowed types: JPG, PNG, WEBP, GIF, or Lottie JSON.'];
        }

        if (!is_dir($target) && !mkdir($target, 0755, true) && !is_dir($target)) {
            return ['ok' => false, 'message' => 'Upload folder is not writable.'];
        }
        if (is_file($target . '/' . $name)) {
            $name = pathinfo($name, PATHINFO_FILENAME) . '-' . bin2hex(random_bytes(3)) . '.' . $ext;
        }
        if (!move_uploaded_file($file['tmp_name'], $target . '/' . $name)) {
            return ['ok' => false, 'message' => 'Could not save the file. Check folder permissions.'];
        }
        @chmod($target . '/' . $name, 0644);

        return ['ok' => true, 'message' => 'Uploaded.', 'name' => $name];
    }

    /** Delete a file by name from the image or animation folder. */
    public static function delete(string $name, string $kind): bool
    {
        $name = basename($name);
        $dir = $kind === 'animation' ? self::dir('images') : self::dir();
        $path = $dir . '/' . $name;
        return $name !== '' && $name[0] !== '.' && is_file($path) && unlink($path);
    }
}

<?php

declare(strict_types=1);

namespace App\Services;

use App\Core\Database;

/**
 * Single place where player balances change.
 *
 * Replaces the old MySQL triggers: every balance change is a ledger row in
 * `usertransaction` plus an atomic update of `userbalance`, in one DB
 * transaction, with the balance row locked – so two requests can no longer
 * overspend the same money.
 */
final class Wallet
{
    public static function balance(int $userId): int
    {
        return (int) (Database::value('SELECT balance FROM userbalance WHERE userid = ?', [$userId]) ?? 0);
    }

    /**
     * Apply a signed amount (+credit / -debit) and write the ledger row.
     *
     * @param array{paytmnumber?:?string,instaorderid?:?string,instatxnid?:?string,instapaymentid?:?string,instatoken?:?string} $extra
     * @throws InsufficientFunds when a debit would take the balance below zero
     * @return int ledger id (trnid)
     */
    public static function apply(int $userId, int $amount, string $status, array $extra = []): int
    {
        return Database::transaction(static function () use ($userId, $amount, $status, $extra): int {
            Database::exec('INSERT IGNORE INTO userbalance (userid, balance, log_entdate) VALUES (?, 0, ?)', [$userId, date('Y-m-d H:i:s')]);

            $balance = (int) Database::value('SELECT balance FROM userbalance WHERE userid = ? FOR UPDATE', [$userId]);
            if ($amount < 0 && $balance + $amount < 0) {
                throw new InsufficientFunds('Insufficient balance.');
            }

            Database::exec('UPDATE userbalance SET balance = balance + ? WHERE userid = ?', [$amount, $userId]);

            return Database::insert(
                'INSERT INTO usertransaction
                    (userid, amount, type, paytmnumber, instaorderid, instatxnid, instapaymentid, instatoken, status, log_entdate)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                [
                    $userId,
                    $amount,
                    $amount >= 0 ? 1 : 0,
                    $extra['paytmnumber'] ?? null,
                    $extra['instaorderid'] ?? null,
                    $extra['instatxnid'] ?? null,
                    $extra['instapaymentid'] ?? null,
                    $extra['instatoken'] ?? null,
                    mb_substr($status, 0, 250),
                    date('Y-m-d H:i:s'),
                ]
            );
        });
    }
}

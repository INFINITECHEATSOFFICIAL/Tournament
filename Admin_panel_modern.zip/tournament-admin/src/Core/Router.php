<?php

declare(strict_types=1);

namespace App\Core;

final class Router
{
    /** @var array<string,list<array{0:string,1:array{0:class-string,1:string}}>> */
    private array $routes = ['GET' => [], 'POST' => []];

    public function get(string $pattern, array $handler): void
    {
        $this->routes['GET'][] = [$this->compile($pattern), $handler];
    }

    public function post(string $pattern, array $handler): void
    {
        $this->routes['POST'][] = [$this->compile($pattern), $handler];
    }

    /** `{id}` matches digits, any other `{name}` matches one path segment. */
    private function compile(string $pattern): string
    {
        $regex = preg_replace_callback('/\{(\w+)\}/', static function (array $m): string {
            return $m[1] === 'id' || str_ends_with($m[1], 'Id')
                ? '(?P<' . $m[1] . '>\d+)'
                : '(?P<' . $m[1] . '>[^/]+)';
        }, $pattern);
        return '#^' . $regex . '$#';
    }

    public function dispatch(Request $request): Response
    {
        foreach ($this->routes[$request->method] ?? [] as [$regex, $handler]) {
            if (preg_match($regex, $request->path, $matches)) {
                $params = array_filter($matches, 'is_string', ARRAY_FILTER_USE_KEY);
                // Digits become ints so controller methods can type-hint `int $id`.
                $args = array_map(
                    static fn (string $v): int|string => ctype_digit($v) ? (int) $v : $v,
                    array_values($params)
                );
                [$class, $method] = $handler;
                return (new $class())->$method($request, ...$args);
            }
        }
        return Response::html(View::render('errors/error', [
            'title' => 'Page not found',
            'code' => 404,
            'message' => 'The page you are looking for does not exist.',
        ], 'layouts/app'), 404);
    }
}

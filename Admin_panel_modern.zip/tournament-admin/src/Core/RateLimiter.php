<?php

declare(strict_types=1);

namespace App\Core;

/** Failed-login throttling backed by the `login_attempts` table. */
final class RateLimiter
{
    public static function tooMany(string $scope, string $identifier, string $ip, int $maxPerIdentifier, int $maxPerIp, int $minutes): bool
    {
        $since = date('Y-m-d H:i:s', time() - $minutes * 60);

        $byIdentifier = (int) Database::value(
            'SELECT COUNT(*) FROM login_attempts WHERE scope = ? AND identifier = ? AND created_at >= ?',
            [$scope, $identifier, $since]
        );
        if ($byIdentifier >= $maxPerIdentifier) {
            return true;
        }

        $byIp = (int) Database::value(
            'SELECT COUNT(*) FROM login_attempts WHERE scope = ? AND ip = ? AND created_at >= ?',
            [$scope, $ip, $since]
        );
        return $byIp >= $maxPerIp;
    }

    public static function hit(string $scope, string $identifier, string $ip): void
    {
        Database::exec(
            'INSERT INTO login_attempts (scope, identifier, ip, created_at) VALUES (?, ?, ?, ?)',
            [$scope, mb_substr($identifier, 0, 100), $ip, date('Y-m-d H:i:s')]
        );
        // Opportunistic cleanup keeps the table tiny.
        if (random_int(1, 50) === 1) {
            Database::exec('DELETE FROM login_attempts WHERE created_at < ?', [date('Y-m-d H:i:s', time() - 86400)]);
        }
    }

    public static function clear(string $scope, string $identifier): void
    {
        Database::exec('DELETE FROM login_attempts WHERE scope = ? AND identifier = ?', [$scope, $identifier]);
    }
}

<?php

declare(strict_types=1);

namespace App\Core;

final class View
{
    /** Render a template inside a layout. */
    public static function render(string $template, array $data = [], string $layout = 'layouts/app'): string
    {
        $content = self::partial($template, $data);
        return self::partial($layout, $data + ['content' => $content]);
    }

    /** Render a template on its own (no layout). */
    public static function partial(string $template, array $data = []): string
    {
        $file = BASE_PATH . '/templates/' . $template . '.php';
        if (!is_file($file)) {
            throw new \RuntimeException("Template not found: {$template}");
        }
        extract($data, EXTR_SKIP);
        ob_start();
        try {
            require $file;
            return (string) ob_get_clean();
        } catch (\Throwable $e) {
            ob_end_clean();
            throw $e;
        }
    }
}

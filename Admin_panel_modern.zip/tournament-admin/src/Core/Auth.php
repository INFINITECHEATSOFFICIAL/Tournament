<?php

declare(strict_types=1);

namespace App\Core;

/** Admin authentication (bcrypt/argon hashes, throttling, session fixation protection). */
final class Auth
{
    private static ?array $user = null;

    public static function check(): bool
    {
        return self::user() !== null;
    }

    /** @return array{id:int,username:string,display_name:string}|null */
    public static function user(): ?array
    {
        if (self::$user !== null) {
            return self::$user;
        }
        $id = Session::get('admin_id');
        if (!$id) {
            return null;
        }
        $row = Database::one(
            'SELECT id, username, display_name FROM admins WHERE id = ? AND is_active = 1',
            [(int) $id]
        );
        if ($row === null) {
            Session::forget('admin_id');
            return null;
        }
        return self::$user = $row;
    }

    /** @return array{ok:bool,error:?string} */
    public static function attempt(string $username, string $password): array
    {
        $ip = Request::ip();
        $max = max(1, (int) (env('LOGIN_MAX_ATTEMPTS', '5') ?? 5));
        $minutes = max(1, (int) (env('LOGIN_LOCK_MINUTES', '15') ?? 15));
        $key = mb_strtolower($username);

        if (RateLimiter::tooMany('admin', $key, $ip, $max * 2, $max, $minutes)) {
            return ['ok' => false, 'error' => "Too many failed attempts. Try again in {$minutes} minutes."];
        }

        $admin = Database::one(
            'SELECT id, password_hash FROM admins WHERE username = ? AND is_active = 1',
            [$username]
        );

        // Always run password_verify so response time doesn't reveal valid usernames.
        static $dummy = null;
        $dummy ??= password_hash(bin2hex(random_bytes(8)), PASSWORD_DEFAULT);
        $valid = password_verify($password, $admin['password_hash'] ?? $dummy) && $admin !== null;

        if (!$valid) {
            RateLimiter::hit('admin', $key, $ip);
            return ['ok' => false, 'error' => 'Invalid username or password.'];
        }

        RateLimiter::clear('admin', $key);
        Session::regenerate();
        Session::set('admin_id', (int) $admin['id']);

        if (password_needs_rehash($admin['password_hash'], PASSWORD_DEFAULT)) {
            Database::exec('UPDATE admins SET password_hash = ? WHERE id = ?', [password_hash($password, PASSWORD_DEFAULT), $admin['id']]);
        }
        Database::exec('UPDATE admins SET last_login_at = ? WHERE id = ?', [date('Y-m-d H:i:s'), $admin['id']]);

        return ['ok' => true, 'error' => null];
    }

    public static function logout(): void
    {
        self::$user = null;
        Session::destroy();
    }

    public static function adminCount(): int
    {
        return (int) Database::value('SELECT COUNT(*) FROM admins');
    }
}

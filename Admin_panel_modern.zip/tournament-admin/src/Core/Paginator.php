<?php

declare(strict_types=1);

namespace App\Core;

final class Paginator
{
    public int $pages;
    public int $offset;

    public function __construct(public int $total, public int $page, public int $perPage = 20)
    {
        $this->perPage = max(1, $perPage);
        $this->pages = max(1, (int) ceil($total / $this->perPage));
        $this->page = min(max(1, $page), $this->pages);
        $this->offset = ($this->page - 1) * $this->perPage;
    }

    /** SQL fragment – both numbers are integers, so interpolation is safe. */
    public function limitSql(): string
    {
        return ' LIMIT ' . (int) $this->perPage . ' OFFSET ' . (int) $this->offset;
    }
}

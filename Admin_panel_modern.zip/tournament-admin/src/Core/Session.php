<?php

declare(strict_types=1);

namespace App\Core;

/** Hardened session handling + flash messages + CSRF tokens. */
final class Session
{
    public static function start(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            return;
        }

        ini_set('session.use_strict_mode', '1');
        ini_set('session.use_only_cookies', '1');
        ini_set('session.cookie_httponly', '1');

        session_name(env('SESSION_NAME', 'bw_admin') ?? 'bw_admin');
        session_set_cookie_params([
            'lifetime' => 0,
            'path' => Request::basePath() ?: '/',
            'secure' => Request::isSecure(),
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        session_start();

        // Idle timeout.
        $lifetime = (int) (env('SESSION_LIFETIME', '7200') ?? 7200);
        if (isset($_SESSION['_last_seen']) && time() - (int) $_SESSION['_last_seen'] > $lifetime) {
            self::destroy();
            session_start();
        }
        $_SESSION['_last_seen'] = time();
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        return $_SESSION[$key] ?? $default;
    }

    public static function set(string $key, mixed $value): void
    {
        $_SESSION[$key] = $value;
    }

    public static function forget(string $key): void
    {
        unset($_SESSION[$key]);
    }

    public static function regenerate(): void
    {
        session_regenerate_id(true);
    }

    public static function destroy(): void
    {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', [
                'expires' => time() - 42000,
                'path' => $p['path'],
                'domain' => $p['domain'],
                'secure' => $p['secure'],
                'httponly' => true,
                'samesite' => 'Lax',
            ]);
        }
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_destroy();
        }
    }

    // ── Flash messages ────────────────────────────────────────────────
    public static function flash(string $type, string $message): void
    {
        $_SESSION['_flash'][] = ['type' => $type, 'message' => $message];
    }

    /** @return list<array{type:string,message:string}> */
    public static function pullFlash(): array
    {
        $messages = $_SESSION['_flash'] ?? [];
        unset($_SESSION['_flash']);
        return $messages;
    }

    // ── Old form input (after validation errors) ──────────────────────
    public static function flashInput(array $input, array $errors = []): void
    {
        unset($input['_token'], $input['password'], $input['current_password'], $input['new_password'], $input['confirm_password']);
        $_SESSION['_old'] = $input;
        $_SESSION['_errors'] = $errors;
    }

    public static function old(string $key, mixed $default = ''): mixed
    {
        return $_SESSION['_old_now'][$key] ?? $default;
    }

    /** @return array<string,string> */
    public static function errors(): array
    {
        return $_SESSION['_errors_now'] ?? [];
    }

    /** Called once per request: promotes flashed input to "current" and clears it. */
    public static function rotateInput(): void
    {
        $_SESSION['_old_now'] = $_SESSION['_old'] ?? [];
        $_SESSION['_errors_now'] = $_SESSION['_errors'] ?? [];
        unset($_SESSION['_old'], $_SESSION['_errors']);
    }

    // ── CSRF ──────────────────────────────────────────────────────────
    public static function csrfToken(): string
    {
        if (empty($_SESSION['_csrf'])) {
            $_SESSION['_csrf'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['_csrf'];
    }

    public static function verifyCsrf(?string $token): bool
    {
        return is_string($token) && $token !== ''
            && isset($_SESSION['_csrf'])
            && hash_equals($_SESSION['_csrf'], $token);
    }
}

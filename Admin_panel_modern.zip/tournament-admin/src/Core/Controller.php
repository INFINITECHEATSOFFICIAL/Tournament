<?php

declare(strict_types=1);

namespace App\Core;

abstract class Controller
{
    protected function view(string $template, array $data = [], int $status = 200): Response
    {
        return Response::html(View::render($template, $data), $status);
    }

    protected function redirect(string $path, ?string $flashType = null, ?string $flashMessage = null): Response
    {
        if ($flashType !== null && $flashMessage !== null) {
            Session::flash($flashType, $flashMessage);
        }
        return Response::redirect(url($path));
    }

    /** Redirect back to a form with errors + the submitted values. */
    protected function backWithErrors(string $path, Request $request, array $errors): Response
    {
        Session::flashInput($request->post(), $errors);
        Session::flash('error', 'Please fix the highlighted fields and try again.');
        return Response::redirect(url($path));
    }

    protected function notFound(string $what = 'Page'): Response
    {
        return $this->view('errors/error', [
            'title' => "{$what} not found",
            'code' => 404,
            'message' => "That {$what} does not exist or was removed.",
        ], 404);
    }
}

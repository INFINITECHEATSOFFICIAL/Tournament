<?php

declare(strict_types=1);

namespace App\Core;

/** Small fluent validator. Collects cleaned values in $clean and messages in $errors. */
final class Validator
{
    /** @var array<string,string> */
    public array $errors = [];
    /** @var array<string,mixed> */
    public array $clean = [];

    public function __construct(private array $data)
    {
    }

    private function raw(string $field): string
    {
        $v = $this->data[$field] ?? '';
        return is_string($v) ? trim($v) : '';
    }

    public function string(string $field, string $label, int $min = 0, int $max = 255, bool $required = true): self
    {
        $v = $this->raw($field);
        if ($v === '') {
            if ($required) {
                $this->errors[$field] = "{$label} is required.";
            }
            $this->clean[$field] = $v === '' ? null : $v;
            return $this;
        }
        $len = mb_strlen($v);
        if ($len < $min) {
            $this->errors[$field] = "{$label} must be at least {$min} characters.";
        } elseif ($len > $max) {
            $this->errors[$field] = "{$label} must be at most {$max} characters.";
        }
        $this->clean[$field] = $v;
        return $this;
    }

    public function int(string $field, string $label, int $min = 0, int $max = 2147483647, bool $required = true): self
    {
        $v = $this->raw($field);
        if ($v === '') {
            if ($required) {
                $this->errors[$field] = "{$label} is required.";
            }
            $this->clean[$field] = null;
            return $this;
        }
        if (!preg_match('/^-?\d+$/', $v)) {
            $this->errors[$field] = "{$label} must be a whole number.";
            return $this;
        }
        $n = (int) $v;
        if ($n < $min || $n > $max) {
            $this->errors[$field] = "{$label} must be between {$min} and {$max}.";
        }
        $this->clean[$field] = $n;
        return $this;
    }

    /** @param list<string> $allowed */
    public function in(string $field, string $label, array $allowed, bool $required = true): self
    {
        $v = $this->raw($field);
        if ($v === '' && !$required) {
            $this->clean[$field] = null;
            return $this;
        }
        if (!in_array($v, $allowed, true)) {
            $this->errors[$field] = "Please choose a valid {$label}.";
            return $this;
        }
        $this->clean[$field] = $v;
        return $this;
    }

    /** Accepts HTML datetime-local values (Y-m-d\TH:i[:s]) and returns "Y-m-d H:i:s". */
    public function datetime(string $field, string $label): self
    {
        $v = $this->raw($field);
        $dt = \DateTimeImmutable::createFromFormat('Y-m-d\TH:i', $v)
            ?: \DateTimeImmutable::createFromFormat('Y-m-d\TH:i:s', $v)
            ?: \DateTimeImmutable::createFromFormat('Y-m-d H:i:s', $v);
        if ($dt === false) {
            $this->errors[$field] = "{$label} must be a valid date and time.";
            return $this;
        }
        $this->clean[$field] = $dt->format('Y-m-d H:i:s');
        return $this;
    }

    public function fails(): bool
    {
        return $this->errors !== [];
    }
}

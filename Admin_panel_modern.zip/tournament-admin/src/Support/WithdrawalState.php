<?php

declare(strict_types=1);

namespace App\Support;

/**
 * Withdrawals live in `usertransaction` and their state is a free-text `status`.
 * This class classifies that text (works for the old hand-typed remarks too).
 */
final class WithdrawalState
{
    public const PENDING = 'pending';
    public const COMPLETED = 'completed';
    public const REJECTED = 'rejected';

    private const DONE_WORDS = ['success', 'complete', 'done', 'paid'];
    private const REJECT_WORDS = ['reject', 'declin', 'fail', 'cancel'];

    public const LABEL_PENDING = 'Withdrawal Pending';
    public const LABEL_COMPLETED = 'Withdrawal Completed';
    public const LABEL_REJECTED = 'Withdrawal Rejected';

    public static function classify(string $status): string
    {
        $s = strtolower($status);
        foreach (self::REJECT_WORDS as $w) {
            if (str_contains($s, $w)) {
                return self::REJECTED;
            }
        }
        foreach (self::DONE_WORDS as $w) {
            if (str_contains($s, $w)) {
                return self::COMPLETED;
            }
        }
        return self::PENDING;
    }

    /** SQL condition (no user input inside) matching rows in the given state. */
    public static function sql(string $state, string $col = 't.status'): string
    {
        $like = static fn (array $words): string => '(' . implode(' OR ', array_map(
            static fn (string $w): string => "{$col} LIKE '%{$w}%'",
            $words
        )) . ')';

        return match ($state) {
            self::REJECTED => $like(self::REJECT_WORDS),
            self::COMPLETED => '(NOT ' . $like(self::REJECT_WORDS) . ' AND ' . $like(self::DONE_WORDS) . ')',
            self::PENDING => '(NOT ' . $like(self::REJECT_WORDS) . ' AND NOT ' . $like(self::DONE_WORDS) . ')',
            default => '1=1',
        };
    }

    /** Base condition identifying a withdrawal request row. */
    public static function isWithdrawalSql(string $col = 't.status'): string
    {
        return "{$col} LIKE '%withdrawal%'";
    }

    public static function badge(string $status): string
    {
        return match (self::classify($status)) {
            self::COMPLETED => badge('Completed', 'success'),
            self::REJECTED => badge('Rejected', 'danger'),
            default => badge('Pending', 'warn'),
        };
    }
}

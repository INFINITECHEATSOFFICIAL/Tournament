<?php

declare(strict_types=1);

namespace App\Support;

/** Dropdown values used by the match form. Edit here to add new maps/modes. */
final class Options
{
    public const MATCH_TYPES = ['SOLO', 'DUO', 'SQUAD'];
    public const MAPS = ['Erangel', 'Miramar', 'Vikendi', 'Sanhok', 'Livik', 'Karakin'];
    public const FEE_TYPES = ['Paid', 'Free'];
    public const STATUSES = ['upcoming', 'ongoing', 'done'];
    public const VERSIONS = ['1.0'];
}

<div class="toolbar">
  <form class="search" method="get" action="<?= e(url('/scores')) ?>">
    <?= icon('search') ?><input class="input" type="number" name="match" min="1" value="<?= e($lookup) ?>" placeholder="Jump to match ID…">
  </form>
</div>
<section class="card">
  <header class="card-head"><h2>Matches ready for results</h2></header>
  <?php if (!$matches): ?><div class="empty"><p class="muted">No live or finished matches yet.</p></div><?php else: ?>
  <div class="table-wrap"><table class="table">
    <thead><tr><th>#</th><th>Match</th><th>Started</th><th>Players</th><th>Status</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($matches as $m): ?>
      <tr>
        <td>#<?= (int) $m['matchid'] ?></td>
        <td><?= e($m['type']) ?> · <?= e($m['map']) ?></td>
        <td><?= fmt_dt($m['matchschedule']) ?></td>
        <td><?= (int) $m['totalplayerjoined'] ?></td>
        <td><?= match_status_badge($m['matchstatus']) ?></td>
        <td class="right"><a class="btn btn-sm btn-primary" href="<?= e(url('/scores/' . $m['matchid'])) ?>">Enter scores</a></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?php endif; ?>
</section>

<?php $m = $match; ?>
<div class="toolbar">
  <a class="btn" href="<?= e(url('/scores')) ?>">‹ Back</a>
  <span class="muted">Match #<?= (int) $m['matchid'] ?> · <?= e($m['type']) ?> · <?= e($m['map']) ?></span>
  <?= match_status_badge($m['matchstatus']) ?>
</div>

<?php if (!$players): ?>
  <section class="card"><div class="empty"><p class="muted">No players joined this match.</p></div></section>
<?php else: ?>
<form method="post" action="<?= e(url('/scores/' . $m['matchid'])) ?>" class="card" id="score-form"
      data-perkill="<?= (int) $m['perkill'] ?>" data-winprice="<?= (int) $m['winprice'] ?>">
  <?= csrf_field() ?>
  <header class="card-head">
    <h2>Results <span class="count"><?= count($players) ?></span></h2>
    <div class="head-actions">
      <span class="muted">Prize: <?= e(money($m['winprice'])) ?> winner · <?= e(money($m['perkill'])) ?>/kill</span>
      <button class="btn btn-sm" type="button" data-autocalc title="Winnings = kills × per-kill prize, plus the winner prize for rank 1">Auto-calculate</button>
    </div>
  </header>
  <div class="table-wrap"><table class="table table-inputs">
    <thead><tr><th>Player</th><th>PUBG name</th><th>Kills</th><th>Rank</th><th>Winner</th><th>Winnings</th></tr></thead>
    <tbody>
    <?php foreach ($players as $p): $k = (int) $p['userid']; ?>
      <tr data-row>
        <td><a href="<?= e(url('/players/' . $k)) ?>"><?= e(trim($p['firstname'] . ' ' . $p['lastname'])) ?></a><small class="muted"> @<?= e($p['username']) ?></small></td>
        <td><?= e($p['pubgusername'] ?: '—') ?></td>
        <td><input class="input input-sm" type="number" min="0" name="rows[<?= $k ?>][kills]" value="<?= (int) $p['kills'] ?>" data-kills></td>
        <td><input class="input input-sm" type="number" min="1" name="rows[<?= $k ?>][rank]" value="<?= $p['rank'] !== null ? (int) $p['rank'] : '' ?>" data-rank placeholder="—"></td>
        <td><label class="switch"><input type="checkbox" name="rows[<?= $k ?>][won]" value="1" <?= $p['won'] === 'Y' ? 'checked' : '' ?> data-won><span></span></label></td>
        <td><input class="input input-sm" type="number" min="0" name="rows[<?= $k ?>][wonamount]" value="<?= (int) $p['wonamount'] ?>" data-amount></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <footer class="form-actions">
    <label class="check"><input type="checkbox" name="mark_done" value="1" <?= $m['matchstatus'] !== 'done' ? '' : 'disabled' ?>> Mark match as completed</label>
    <button class="btn btn-primary" type="submit">Save results</button>
  </footer>
  <p class="hint">Changing a player's winnings credits or debits only the <em>difference</em> in their wallet, so saving twice never pays twice.</p>
</form>
<?php endif; ?>

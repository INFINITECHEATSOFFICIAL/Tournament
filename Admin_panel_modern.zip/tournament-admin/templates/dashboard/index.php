<section class="stats">
  <div class="stat"><span class="stat-label">Players</span><strong><?= number_format($stats['players']) ?></strong><small class="muted">+<?= (int) $stats['new_players'] ?> this week</small></div>
  <div class="stat"><span class="stat-label">Live / upcoming matches</span><strong><?= (int) $matchCounts['ongoing'] ?> / <?= (int) $matchCounts['upcoming'] ?></strong><small class="muted"><?= (int) $matchCounts['done'] ?> completed</small></div>
  <div class="stat"><span class="stat-label">Player wallets (owed)</span><strong><?= e(money($stats['wallet_total'])) ?></strong><small class="muted">sum of all balances</small></div>
  <div class="stat"><span class="stat-label">Deposits · 30 days</span><strong><?= e(money($stats['deposits_30d'])) ?></strong><small class="muted">winnings paid: <?= e(money($stats['payouts_30d'])) ?></small></div>
  <a class="stat stat-link<?= $stats['pending_count'] > 0 ? ' stat-alert' : '' ?>" href="<?= e(url('/withdrawals')) ?>"><span class="stat-label">Pending withdrawals</span><strong><?= (int) $stats['pending_count'] ?></strong><small><?= e(money($stats['pending_total'])) ?> to pay out</small></a>
</section>

<div class="grid-2">
  <section class="card">
    <header class="card-head"><h2>Live &amp; upcoming matches</h2><a class="btn btn-sm btn-primary" href="<?= e(url('/matches/create')) ?>"><?= icon('plus') ?>New match</a></header>
    <?php if (!$upcoming): ?>
      <div class="empty"><p class="muted">No matches scheduled.</p></div>
    <?php else: ?>
    <div class="table-wrap"><table class="table">
      <thead><tr><th>#</th><th>Match</th><th>Starts</th><th>Slots</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($upcoming as $m): ?>
        <tr>
          <td><a href="<?= e(url('/matches/' . $m['matchid'])) ?>">#<?= (int) $m['matchid'] ?></a></td>
          <td><?= e($m['type']) ?> · <?= e($m['map']) ?> <?= match_status_badge($m['matchstatus']) ?></td>
          <td><?= fmt_dt($m['matchschedule']) ?></td>
          <td><progress max="<?= max(1, (int) $m['totalplayer']) ?>" value="<?= (int) $m['totalplayerjoined'] ?>"></progress> <small><?= (int) $m['totalplayerjoined'] ?>/<?= (int) $m['totalplayer'] ?></small></td>
          <td class="right"><a class="btn btn-sm" href="<?= e(url('/matches/' . $m['matchid'] . '/edit')) ?>">Edit</a></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
    <?php endif; ?>
  </section>

  <section class="card">
    <header class="card-head"><h2>Recent transactions</h2><a class="btn btn-sm" href="<?= e(url('/transactions')) ?>">View all</a></header>
    <?php if (!$recent): ?>
      <div class="empty"><p class="muted">No transactions yet.</p></div>
    <?php else: ?>
    <ul class="feed">
      <?php foreach ($recent as $t): ?>
        <li>
          <div><a href="<?= e(url('/players/' . $t['userid'])) ?>"><?= e($t['username'] ?? ('#' . $t['userid'])) ?></a><small class="muted"><?= e($t['status']) ?> · <?= fmt_dt($t['log_entdate'], 'd M, h:i A') ?></small></div>
          <strong class="<?= (int) $t['amount'] >= 0 ? 'pos' : 'neg' ?>"><?= (int) $t['amount'] >= 0 ? '+' : '' ?><?= e(money($t['amount'])) ?></strong>
        </li>
      <?php endforeach; ?>
    </ul>
    <?php endif; ?>
  </section>
</div>

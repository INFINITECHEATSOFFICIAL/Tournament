<div class="tabs tabs-solo">
  <?php foreach (['pending' => 'Pending', 'completed' => 'Completed', 'rejected' => 'Rejected', 'all' => 'All'] as $k => $label): ?>
    <a class="tab<?= $state === $k ? ' is-active' : '' ?>" href="<?= e(url('/withdrawals', ['state' => $k])) ?>"><?= e($label) ?> <span class="count"><?= (int) ($counts[$k] ?? 0) ?></span></a>
  <?php endforeach; ?>
</div>

<section class="card">
<?php if (!$rows): ?><div class="empty"><p class="muted">Nothing here. 🎉</p></div><?php else: ?>
  <div class="table-wrap"><table class="table">
    <thead><tr><th>#</th><th>Player</th><th>Paytm number</th><th class="right">Amount</th><th>Requested</th><th>Status</th><th>Action</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r):
        $st = \App\Support\WithdrawalState::classify((string) $r['status']); ?>
      <tr>
        <td><?= (int) $r['trnid'] ?></td>
        <td><a href="<?= e(url('/players/' . $r['userid'])) ?>"><?= e($r['username'] ?? ('#' . $r['userid'])) ?></a><small class="muted"><?= e($r['mobile'] ?? '') ?></small></td>
        <td><strong><?= e($r['paytmnumber'] ?: '—') ?></strong></td>
        <td class="right"><?= e(money(abs((int) $r['amount']))) ?></td>
        <td><?= fmt_dt($r['log_entdate']) ?></td>
        <td><?= \App\Support\WithdrawalState::badge((string) $r['status']) ?><small class="muted"><?= e($r['status']) ?></small></td>
        <td>
          <?php if ($st === 'pending'): ?>
            <form method="post" action="<?= e(url('/withdrawals/' . $r['trnid'])) ?>" class="inline-form">
              <?= csrf_field() ?><input type="hidden" name="state" value="<?= e($state) ?>">
              <input class="input input-sm" name="note" maxlength="80" placeholder="UTR / note (optional)" aria-label="Note">
              <button class="btn btn-sm btn-success" name="action" value="complete" data-confirm="Mark #<?= (int) $r['trnid'] ?> as paid?"><?= icon('check') ?>Paid</button>
              <button class="btn btn-sm btn-danger" name="action" value="reject" data-confirm="Reject #<?= (int) $r['trnid'] ?> and refund the player?"><?= icon('x') ?>Reject</button>
            </form>
          <?php elseif ($st === 'completed'): ?>
            <form method="post" action="<?= e(url('/withdrawals/' . $r['trnid'])) ?>"><?= csrf_field() ?><input type="hidden" name="state" value="<?= e($state) ?>"><button class="btn btn-sm" name="action" value="reopen" data-confirm="Move back to pending?">Re-open</button></form>
          <?php else: ?><span class="muted">Refunded</span><?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?= partial('partials/pagination', ['pager' => $pager]) ?>
<?php endif; ?>
</section>

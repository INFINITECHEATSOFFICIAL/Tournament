<form class="card filters" method="get" action="<?= e(url('/transactions')) ?>">
  <label class="field"><span>Search</span><input class="input" name="q" value="<?= e($f['q']) ?>" placeholder="Player, ID, remark, Paytm no."></label>
  <label class="field"><span>Type</span>
    <select class="input" name="kind"><option value="">All</option><?php foreach ($kinds as $k): ?><option value="<?= e($k) ?>"<?= $f['kind'] === $k ? ' selected' : '' ?>><?= e(ucfirst($k)) ?></option><?php endforeach; ?></select></label>
  <label class="field"><span>Direction</span>
    <select class="input" name="direction"><option value="">Both</option><option value="credit"<?= $f['direction'] === 'credit' ? ' selected' : '' ?>>Credits</option><option value="debit"<?= $f['direction'] === 'debit' ? ' selected' : '' ?>>Debits</option></select></label>
  <label class="field"><span>From</span><input class="input" type="date" name="from" value="<?= e($f['from']) ?>"></label>
  <label class="field"><span>To</span><input class="input" type="date" name="to" value="<?= e($f['to']) ?>"></label>
  <div class="filters-actions">
    <button class="btn btn-primary" type="submit">Filter</button>
    <a class="btn" href="<?= e(url('/transactions')) ?>">Reset</a>
    <a class="btn" href="<?= e(url('/transactions/export', array_filter($f))) ?>"><?= icon('download') ?>CSV</a>
  </div>
</form>

<section class="stats stats-3">
  <div class="stat"><span class="stat-label">Matching rows</span><strong><?= number_format((int) $sum['c']) ?></strong></div>
  <div class="stat"><span class="stat-label">Money in</span><strong class="pos"><?= e(money($sum['credits'])) ?></strong></div>
  <div class="stat"><span class="stat-label">Money out</span><strong class="neg"><?= e(money($sum['debits'])) ?></strong></div>
</section>

<section class="card">
<?php if (!$rows): ?><div class="empty"><p class="muted">No transactions match these filters.</p></div><?php else: ?>
  <div class="table-wrap"><table class="table">
    <thead><tr><th>#</th><th>Player</th><th>Remark</th><th>Paytm no.</th><th>Date</th><th class="right">Amount</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td><?= (int) $r['trnid'] ?></td>
        <td><a href="<?= e(url('/players/' . $r['userid'])) ?>"><?= e($r['username'] ?? ('#' . $r['userid'])) ?></a><small class="muted"><?= e(trim(($r['firstname'] ?? '') . ' ' . ($r['lastname'] ?? ''))) ?></small></td>
        <td><?= e($r['status']) ?></td>
        <td><?= e($r['paytmnumber'] ?: '—') ?></td>
        <td><?= fmt_dt($r['log_entdate']) ?></td>
        <td class="right <?= (int) $r['amount'] >= 0 ? 'pos' : 'neg' ?>"><?= (int) $r['amount'] >= 0 ? '+' : '' ?><?= e(money($r['amount'])) ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?= partial('partials/pagination', ['pager' => $pager]) ?>
<?php endif; ?>
</section>

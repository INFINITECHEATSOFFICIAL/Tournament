<section class="card">
  <header class="card-head"><h2>Add a rule</h2></header>
  <form method="post" action="<?= e(url('/rules')) ?>" class="inline-form pad">
    <?= csrf_field() ?>
    <input class="input grow" name="rules" maxlength="500" placeholder="Rule text shown in the app" required aria-label="Rule text">
    <input class="input input-sm" name="remarkid" value="basic" placeholder="basic or match ID" aria-label="Applies to" required>
    <button class="btn btn-primary" type="submit"><?= icon('plus') ?>Add</button>
  </form>
  <p class="hint">“Applies to” = <code>basic</code> for every match, or a match ID for a single match.</p>
</section>

<section class="card">
  <header class="card-head"><h2>All rules <span class="count"><?= count($rules) ?></span></h2></header>
  <?php if (!$rules): ?><div class="empty"><p class="muted">No rules yet.</p></div><?php else: ?>
  <div class="table-wrap"><table class="table table-inputs">
    <thead><tr><th>Rule</th><th>Applies to</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($rules as $r): $id = (int) $r['rulesid']; ?>
      <tr>
        <td><input class="input" form="rule-<?= $id ?>" name="rules" value="<?= e($r['rules']) ?>" maxlength="500" required aria-label="Rule text"></td>
        <td><input class="input input-sm" form="rule-<?= $id ?>" name="remarkid" value="<?= e($r['remarkid']) ?>" required aria-label="Applies to"></td>
        <td class="actions">
          <form id="rule-<?= $id ?>" method="post" action="<?= e(url('/rules/' . $id)) ?>"><?= csrf_field() ?><button class="btn btn-sm" type="submit">Save</button></form>
          <form method="post" action="<?= e(url('/rules/' . $id . '/delete')) ?>" data-confirm="Delete this rule?"><?= csrf_field() ?><button class="icon-btn icon-danger" aria-label="Delete"><?= icon('trash') ?></button></form>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?php endif; ?>
</section>

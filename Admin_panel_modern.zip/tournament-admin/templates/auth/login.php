<h1 class="auth-title">Welcome back</h1>
<p class="muted center">Sign in to manage tournaments.</p>
<form method="post" action="<?= e(url('/login')) ?>" class="stack" autocomplete="on">
  <?= csrf_field() ?>
  <label class="field"><span>Username</span>
    <input class="input" name="username" value="<?= e(old('username')) ?>" autocomplete="username" required autofocus>
  </label>
  <label class="field"><span>Password</span>
    <input class="input" type="password" name="password" autocomplete="current-password" required>
  </label>
  <button class="btn btn-primary btn-block" type="submit">Sign in</button>
</form>

<?php $errors = \App\Core\Session::errors(); ?>
<h1 class="auth-title">Create the administrator</h1>
<p class="muted center">This page only works while no admin exists. Do it now, then it disappears.</p>
<form method="post" action="<?= e(url('/setup')) ?>" class="stack">
  <?= csrf_field() ?>
  <label class="field"><span>Display name</span>
    <input class="input" name="display_name" value="<?= e(old('display_name')) ?>" required>
    <?php if (isset($errors['display_name'])): ?><em class="error"><?= e($errors['display_name']) ?></em><?php endif; ?>
  </label>
  <label class="field"><span>Username</span>
    <input class="input" name="username" value="<?= e(old('username')) ?>" autocomplete="username" required>
    <?php if (isset($errors['username'])): ?><em class="error"><?= e($errors['username']) ?></em><?php endif; ?>
  </label>
  <label class="field"><span>Password <small>(10+ characters)</small></span>
    <input class="input" type="password" name="password" autocomplete="new-password" required>
    <?php if (isset($errors['password'])): ?><em class="error"><?= e($errors['password']) ?></em><?php endif; ?>
  </label>
  <label class="field"><span>Confirm password</span>
    <input class="input" type="password" name="confirm_password" autocomplete="new-password" required>
    <?php if (isset($errors['confirm_password'])): ?><em class="error"><?= e($errors['confirm_password']) ?></em><?php endif; ?>
  </label>
  <button class="btn btn-primary btn-block" type="submit">Create administrator</button>
</form>

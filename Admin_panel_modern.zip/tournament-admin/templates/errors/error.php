<div class="empty empty-lg">
  <div class="error-code"><?= (int) ($code ?? 500) ?></div>
  <h2><?= e($title ?? 'Error') ?></h2>
  <p class="muted"><?= e($message ?? '') ?></p>
  <p><a class="btn btn-primary" href="<?= e(url('/')) ?>">Back to dashboard</a></p>
</div>

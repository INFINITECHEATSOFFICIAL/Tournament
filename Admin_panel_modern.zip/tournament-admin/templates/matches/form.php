<?php
$isEdit = $match !== null;
$val = static function (string $key, mixed $default = '') use ($match) {
    $o = old($key, null);
    if ($o !== null) { return $o; }
    return $match[$key] ?? $default;
};
$err = static fn (string $k): string => isset($errors[$k]) ? '<em class="error">' . e($errors[$k]) . '</em>' : '';
$action = $isEdit ? '/matches/' . (int) $match['matchid'] : '/matches';
$schedule = $val('matchschedule', date('Y-m-d H:i', strtotime('+1 hour')));
$schedule = str_replace(' ', 'T', substr((string) $schedule, 0, 16));
$sel = static fn (string $key, string $option, string $default = ''): string => (string) $val($key, $default) === $option ? ' selected' : '';
?>
<form method="post" action="<?= e(url($action)) ?>" class="card form-card">
  <?= csrf_field() ?>
  <div class="form-grid">
    <fieldset class="fieldset"><legend>Format</legend>
      <label class="field"><span>Mode</span>
        <select class="input" name="type"><?php foreach ($types as $t): ?><option<?= $sel('type', $t, 'SOLO') ?>><?= e($t) ?></option><?php endforeach; ?></select><?= $err('type') ?></label>
      <label class="field"><span>Map</span>
        <select class="input" name="map"><?php foreach ($maps as $t): ?><option<?= $sel('map', $t, 'Erangel') ?>><?= e($t) ?></option><?php endforeach; ?></select><?= $err('map') ?></label>
      <label class="field"><span>App version</span>
        <select class="input" name="version"><?php foreach ($versions as $t): ?><option<?= $sel('version', $t, '1.0') ?>><?= e($t) ?></option><?php endforeach; ?></select><?= $err('version') ?></label>
      <label class="field"><span>Status</span>
        <select class="input" name="matchstatus"><?php foreach ($statuses as $t): ?><option value="<?= e($t) ?>"<?= $sel('matchstatus', $t, 'upcoming') ?>><?= e(ucfirst($t)) ?></option><?php endforeach; ?></select><?= $err('matchstatus') ?></label>
      <label class="field"><span>Starts at</span>
        <input class="input" type="datetime-local" name="matchschedule" value="<?= e($schedule) ?>" required><?= $err('matchschedule') ?></label>
    </fieldset>

    <fieldset class="fieldset"><legend>Money</legend>
      <label class="field"><span>Entry type</span>
        <select class="input" name="matchtype" id="matchtype"><?php foreach ($feeTypes as $t): ?><option<?= $sel('matchtype', $t, 'Paid') ?>><?= e($t) ?></option><?php endforeach; ?></select><?= $err('matchtype') ?></label>
      <label class="field"><span>Entry fee</span>
        <input class="input" type="number" min="0" name="entryfee" id="entryfee" value="<?= e($val('entryfee', 0)) ?>"><?= $err('entryfee') ?></label>
      <label class="field"><span>Winner prize</span>
        <input class="input" type="number" min="0" name="winprice" value="<?= e($val('winprice', 0)) ?>"><?= $err('winprice') ?></label>
      <label class="field"><span>Prize per kill</span>
        <input class="input" type="number" min="0" name="perkill" value="<?= e($val('perkill', 0)) ?>"><?= $err('perkill') ?></label>
      <label class="field"><span>Total player slots</span>
        <input class="input" type="number" min="1" name="totalplayer" value="<?= e($val('totalplayer', 100)) ?>" required><?= $err('totalplayer') ?>
        <?php if ($isEdit): ?><small class="muted"><?= (int) $match['totalplayerjoined'] ?> already joined</small><?php endif; ?></label>
    </fieldset>

    <fieldset class="fieldset"><legend>Look</legend>
      <label class="field"><span>Banner image</span>
        <select class="input" name="maintopbannerimg"><option value="">— none —</option><?php foreach ($images as $f): ?><option<?= $sel('maintopbannerimg', $f) ?>><?= e($f) ?></option><?php endforeach; ?></select></label>
      <label class="field"><span>Icon image</span>
        <select class="input" name="iconimg"><option value="">— none —</option><?php foreach ($images as $f): ?><option<?= $sel('iconimg', $f) ?>><?= e($f) ?></option><?php endforeach; ?></select></label>
      <small class="muted">Need another image? Upload it under <a href="<?= e(url('/media')) ?>">Media</a>.</small>
    </fieldset>

    <fieldset class="fieldset"><legend>Custom room <small class="muted">(shown to joined players only)</small></legend>
      <label class="field"><span>Room ID</span>
        <input class="input" name="roomid" maxlength="30" value="<?= e($val('roomid', '')) ?>" autocomplete="off"><?= $err('roomid') ?></label>
      <label class="field"><span>Room password</span>
        <input class="input" name="roompassword" maxlength="30" value="<?= e($val('roompassword', '')) ?>" autocomplete="off"><?= $err('roompassword') ?></label>
      <small class="muted">Leave either blank to hide the room from the app.</small>
    </fieldset>
  </div>
  <footer class="form-actions">
    <a class="btn" href="<?= e(url($isEdit ? '/matches/' . (int) $match['matchid'] : '/matches')) ?>">Cancel</a>
    <button class="btn btn-primary" type="submit"><?= $isEdit ? 'Save changes' : 'Create match' ?></button>
  </footer>
</form>

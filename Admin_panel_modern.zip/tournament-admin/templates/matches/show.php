<?php $m = $match; ?>
<div class="toolbar">
  <a class="btn" href="<?= e(url('/matches')) ?>">‹ All matches</a>
  <span class="spacer"></span>
  <a class="btn" href="<?= e(url('/scores/' . $m['matchid'])) ?>"><?= icon('flag') ?>Update scores</a>
  <a class="btn btn-primary" href="<?= e(url('/matches/' . $m['matchid'] . '/edit')) ?>"><?= icon('edit') ?>Edit</a>
</div>

<section class="card">
  <header class="card-head"><h2><?= e($m['type']) ?> · <?= e($m['map']) ?> <?= match_status_badge($m['matchstatus']) ?></h2><span class="muted"><?= fmt_dt($m['matchschedule']) ?></span></header>
  <dl class="facts">
    <div><dt>Entry</dt><dd><?= $m['matchtype'] === 'Free' ? 'Free' : e(money($m['entryfee'])) ?></dd></div>
    <div><dt>Winner prize</dt><dd><?= e(money($m['winprice'])) ?></dd></div>
    <div><dt>Per kill</dt><dd><?= e(money($m['perkill'])) ?></dd></div>
    <div><dt>Slots</dt><dd><?= (int) $m['totalplayerjoined'] ?> / <?= (int) $m['totalplayer'] ?></dd></div>
    <div><dt>Room ID</dt><dd><?= $m['roomid'] ? e($m['roomid']) : '—' ?></dd></div>
    <div><dt>Room password</dt><dd><?= $m['roompassword'] ? e($m['roompassword']) : '—' ?></dd></div>
    <div><dt>App version</dt><dd><?= e($m['version']) ?></dd></div>
    <div><dt>Created</dt><dd><?= fmt_dt($m['log_entdate']) ?></dd></div>
  </dl>
</section>

<section class="card">
  <header class="card-head"><h2>Participants <span class="count"><?= count($players) ?></span></h2></header>
  <?php if (!$players): ?><div class="empty"><p class="muted">Nobody has joined yet.</p></div><?php else: ?>
  <div class="table-wrap"><table class="table">
    <thead><tr><th>Player</th><th>PUBG name</th><th>Kills</th><th>Rank</th><th>Winner</th><th class="right">Won</th></tr></thead>
    <tbody>
    <?php foreach ($players as $p): ?>
      <tr>
        <td><a href="<?= e(url('/players/' . $p['userid'])) ?>"><?= e(trim($p['firstname'] . ' ' . $p['lastname'])) ?></a> <small class="muted">@<?= e($p['username']) ?></small></td>
        <td><?= e($p['pubgusername'] ?: '—') ?></td>
        <td><?= (int) $p['kills'] ?></td>
        <td><?= $p['rank'] !== null ? '#' . (int) $p['rank'] : '—' ?></td>
        <td><?= $p['won'] === 'Y' ? badge('Yes', 'success') : '<span class="muted">No</span>' ?></td>
        <td class="right"><?= e(money($p['wonamount'])) ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?php endif; ?>
</section>

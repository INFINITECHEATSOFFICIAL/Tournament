<div class="toolbar">
  <div class="tabs">
    <?php foreach (['' => 'All', 'upcoming' => 'Upcoming', 'ongoing' => 'Live', 'done' => 'Completed'] as $k => $label): ?>
      <a class="tab<?= $status === $k ? ' is-active' : '' ?>" href="<?= e(url('/matches', ['status' => $k, 'q' => $q])) ?>"><?= e($label) ?> <span class="count"><?= (int) ($k === '' ? $counts['all'] : ($counts[$k] ?? 0)) ?></span></a>
    <?php endforeach; ?>
  </div>
  <form class="search" method="get" action="<?= e(url('/matches')) ?>">
    <input type="hidden" name="status" value="<?= e($status) ?>">
    <?= icon('search') ?><input class="input" type="search" name="q" value="<?= e($q) ?>" placeholder="ID, map, room…">
  </form>
  <a class="btn btn-primary" href="<?= e(url('/matches/create')) ?>"><?= icon('plus') ?>New match</a>
</div>

<section class="card">
<?php if (!$matches): ?>
  <div class="empty"><p class="muted">No matches found.</p></div>
<?php else: ?>
  <div class="table-wrap"><table class="table">
    <thead><tr><th>#</th><th>Match</th><th>Fee</th><th>Prize</th><th>Slots</th><th>Room</th><th>Starts</th><th>Status</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($matches as $m): ?>
      <tr>
        <td><a href="<?= e(url('/matches/' . $m['matchid'])) ?>">#<?= (int) $m['matchid'] ?></a></td>
        <td><strong><?= e($m['type']) ?></strong> · <?= e($m['map']) ?></td>
        <td><?= $m['matchtype'] === 'Free' ? badge('Free', 'info') : e(money($m['entryfee'])) ?></td>
        <td><?= e(money($m['winprice'])) ?><small class="muted"> +<?= e(money($m['perkill'])) ?>/kill</small></td>
        <td><?= (int) $m['totalplayerjoined'] ?>/<?= (int) $m['totalplayer'] ?></td>
        <td><?= $m['roomid'] ? e($m['roomid']) : '<span class="muted">—</span>' ?></td>
        <td><?= fmt_dt($m['matchschedule']) ?></td>
        <td><?= match_status_badge($m['matchstatus']) ?></td>
        <td class="actions">
          <?php if ($m['matchstatus'] === 'upcoming'): ?>
            <form method="post" action="<?= e(url('/matches/' . $m['matchid'] . '/status')) ?>"><?= csrf_field() ?><input type="hidden" name="status" value="ongoing"><input type="hidden" name="return" value="<?= '/matches' ?>"><button class="btn btn-sm" title="Start match"><?= icon('play') ?>Start</button></form>
          <?php elseif ($m['matchstatus'] === 'ongoing'): ?>
            <a class="btn btn-sm" href="<?= e(url('/scores/' . $m['matchid'])) ?>"><?= icon('flag') ?>Scores</a>
          <?php endif; ?>
          <a class="icon-btn" href="<?= e(url('/matches/' . $m['matchid'] . '/edit')) ?>" aria-label="Edit"><?= icon('edit') ?></a>
          <form method="post" action="<?= e(url('/matches/' . $m['matchid'] . '/delete')) ?>" data-confirm="Delete match #<?= (int) $m['matchid'] ?>? Entry fees of joined players will be refunded."><?= csrf_field() ?><button class="icon-btn icon-danger" aria-label="Delete"><?= icon('trash') ?></button></form>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?= partial('partials/pagination', ['pager' => $pager]) ?>
<?php endif; ?>
</section>

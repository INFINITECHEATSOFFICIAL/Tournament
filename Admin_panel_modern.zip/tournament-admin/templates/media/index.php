<section class="card">
  <header class="card-head"><h2>Upload</h2></header>
  <form method="post" action="<?= e(url('/media')) ?>" enctype="multipart/form-data" class="inline-form pad">
    <?= csrf_field() ?>
    <input class="input grow" type="file" name="files[]" multiple accept=".jpg,.jpeg,.png,.webp,.gif,.json" required>
    <button class="btn btn-primary" type="submit">Upload</button>
  </form>
  <p class="hint">Images (JPG, PNG, WEBP, GIF) become selectable as match banners/icons. Lottie <code>.json</code> animations are stored for the app. Max 5 MB each.</p>
</section>

<section class="card">
  <header class="card-head"><h2>Images <span class="count"><?= count($images) ?></span></h2></header>
  <?php if (!$images): ?><div class="empty"><p class="muted">No images uploaded.</p></div><?php else: ?>
  <div class="gallery">
    <?php foreach ($images as $img): ?>
      <figure class="thumb">
        <img src="<?= e(media_url($img['name'])) ?>" alt="<?= e($img['name']) ?>" loading="lazy">
        <figcaption>
          <span class="name" title="<?= e($img['name']) ?>"><?= e($img['name']) ?></span>
          <small class="muted"><?= e(number_format($img['size'] / 1024, 0)) ?> KB · <?= $img['used'] ? 'used by ' . (int) $img['used'] : 'unused' ?></small>
          <form method="post" action="<?= e(url('/media/delete')) ?>" data-confirm="Delete <?= e($img['name']) ?>?"><?= csrf_field() ?><input type="hidden" name="name" value="<?= e($img['name']) ?>"><input type="hidden" name="kind" value="image"><button class="icon-btn icon-danger" aria-label="Delete"><?= icon('trash') ?></button></form>
        </figcaption>
      </figure>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</section>

<section class="card">
  <header class="card-head"><h2>Animations (Lottie JSON) <span class="count"><?= count($animations) ?></span></h2></header>
  <?php if (!$animations): ?><div class="empty"><p class="muted">No animation files.</p></div><?php else: ?>
  <ul class="feed">
    <?php foreach ($animations as $a): ?>
      <li><div><a href="<?= e(media_url($a['name'], 'images')) ?>" target="_blank" rel="noopener"><?= e($a['name']) ?></a><small class="muted"><?= e(number_format($a['size'] / 1024, 0)) ?> KB</small></div>
        <form method="post" action="<?= e(url('/media/delete')) ?>" data-confirm="Delete <?= e($a['name']) ?>?"><?= csrf_field() ?><input type="hidden" name="name" value="<?= e($a['name']) ?>"><input type="hidden" name="kind" value="animation"><button class="icon-btn icon-danger" aria-label="Delete"><?= icon('trash') ?></button></form></li>
    <?php endforeach; ?>
  </ul>
  <?php endif; ?>
</section>

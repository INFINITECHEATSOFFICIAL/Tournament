<?php $err = static fn (string $k): string => isset($errors[$k]) ? '<em class="error">' . e($errors[$k]) . '</em>' : ''; ?>
<div class="grid-2">
  <section class="card">
    <header class="card-head"><h2>Change password</h2></header>
    <form method="post" action="<?= e(url('/settings/password')) ?>" class="stack pad">
      <?= csrf_field() ?>
      <p class="muted">Signed in as <strong><?= e($admin['display_name'] ?? '') ?></strong> (@<?= e($admin['username'] ?? '') ?>)</p>
      <label class="field"><span>Current password</span><input class="input" type="password" name="current_password" autocomplete="current-password" required><?= $err('current_password') ?></label>
      <label class="field"><span>New password <small>(10+ characters)</small></span><input class="input" type="password" name="new_password" autocomplete="new-password" required><?= $err('new_password') ?></label>
      <label class="field"><span>Confirm new password</span><input class="input" type="password" name="confirm_password" autocomplete="new-password" required><?= $err('confirm_password') ?></label>
      <button class="btn btn-primary" type="submit">Update password</button>
    </form>
  </section>

  <section class="card">
    <header class="card-head"><h2>Mobile app version</h2></header>
    <form method="post" action="<?= e(url('/settings/version')) ?>" class="stack pad">
      <?= csrf_field() ?>
      <label class="field"><span>Minimum supported version</span><input class="input" name="oldversion" value="<?= e($version['oldversion']) ?>" required></label>
      <label class="field"><span>Latest version</span><input class="input" name="newversion" value="<?= e($version['newversion']) ?>" required></label>
      <p class="hint">Returned to the app by <code>app_updater.php</code> so it can prompt players to update.</p>
      <button class="btn btn-primary" type="submit">Save</button>
    </form>
  </section>
</div>

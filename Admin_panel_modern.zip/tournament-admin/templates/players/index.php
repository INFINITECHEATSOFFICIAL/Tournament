<div class="toolbar">
  <form class="search search-wide" method="get" action="<?= e(url('/players')) ?>">
    <?= icon('search') ?><input class="input" type="search" name="q" value="<?= e($q) ?>" placeholder="Name, username, email, mobile, PUBG name or ID…">
    <select class="input" name="sort" data-autosubmit aria-label="Sort by">
      <?php foreach (['newest' => 'Newest', 'balance' => 'Highest balance', 'winnings' => 'Most won', 'played' => 'Most matches', 'name' => 'Name A–Z'] as $k => $l): ?>
        <option value="<?= e($k) ?>"<?= $sort === $k ? ' selected' : '' ?>><?= e($l) ?></option>
      <?php endforeach; ?>
    </select>
    <button class="btn" type="submit">Search</button>
  </form>
</div>
<section class="card">
<?php if (!$players): ?><div class="empty"><p class="muted">No players found.</p></div><?php else: ?>
  <div class="table-wrap"><table class="table">
    <thead><tr><th>Player</th><th>PUBG name</th><th>Contact</th><th class="right">Balance</th><th class="right">Matches</th><th class="right">Won</th><th>Joined</th></tr></thead>
    <tbody>
    <?php foreach ($players as $p): ?>
      <tr>
        <td><a href="<?= e(url('/players/' . $p['userid'])) ?>"><strong><?= e(trim($p['firstname'] . ' ' . $p['lastname'])) ?></strong></a><small class="muted">@<?= e($p['username']) ?> · #<?= (int) $p['userid'] ?></small></td>
        <td><?= e($p['pubgusername'] ?: '—') ?></td>
        <td><?= e($p['mobile']) ?><small class="muted"><?= e($p['email']) ?></small></td>
        <td class="right"><?= e(money($p['balance'])) ?></td>
        <td class="right"><?= (int) $p['played'] ?></td>
        <td class="right"><?= e(money($p['won'])) ?></td>
        <td><?= fmt_dt($p['log_entdate'], 'd M Y') ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?= partial('partials/pagination', ['pager' => $pager]) ?>
<?php endif; ?>
</section>

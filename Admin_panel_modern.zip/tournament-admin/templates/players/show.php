<?php $p = $player; ?>
<div class="toolbar"><a class="btn" href="<?= e(url('/players')) ?>">‹ All players</a></div>

<section class="stats">
  <div class="stat"><span class="stat-label">Wallet balance</span><strong><?= e(money($p['balance'])) ?></strong></div>
  <div class="stat"><span class="stat-label">Matches played</span><strong><?= (int) $stats['played'] ?></strong><small class="muted"><?= (int) $stats['wins'] ?> wins</small></div>
  <div class="stat"><span class="stat-label">Total won</span><strong><?= e(money($stats['won'])) ?></strong></div>
  <div class="stat"><span class="stat-label">Total kills</span><strong><?= (int) $stats['kills'] ?></strong></div>
</section>

<div class="grid-2">
  <section class="card">
    <header class="card-head"><h2>Profile</h2></header>
    <dl class="facts facts-col">
      <div><dt>Name</dt><dd><?= e(trim($p['firstname'] . ' ' . $p['lastname'])) ?></dd></div>
      <div><dt>Username</dt><dd>@<?= e($p['username']) ?> <small class="muted">(#<?= (int) $p['userid'] ?>)</small></dd></div>
      <div><dt>PUBG name</dt><dd><?= e($p['pubgusername'] ?: '—') ?></dd></div>
      <div><dt>Email</dt><dd><?= e($p['email']) ?></dd></div>
      <div><dt>Mobile</dt><dd><?= e($p['mobile']) ?></dd></div>
      <div><dt>Promo code</dt><dd><?= e($p['promocode'] ?: '—') ?></dd></div>
      <div><dt>Registered</dt><dd><?= fmt_dt($p['log_entdate']) ?></dd></div>
    </dl>
  </section>

  <section class="card">
    <header class="card-head"><h2>Adjust wallet</h2></header>
    <form method="post" action="<?= e(url('/players/' . $p['userid'] . '/wallet')) ?>" class="stack pad">
      <?= csrf_field() ?>
      <div class="row">
        <label class="field"><span>Action</span><select class="input" name="direction"><option value="credit">Add money</option><option value="debit">Remove money</option></select></label>
        <label class="field"><span>Amount</span><input class="input" type="number" min="1" name="amount" required></label>
      </div>
      <label class="field"><span>Reason <small>(saved in the ledger)</small></span><input class="input" name="reason" maxlength="150" required placeholder="e.g. Refund for disconnected match"></label>
      <button class="btn btn-primary" type="submit" data-confirm="Apply this wallet change?">Apply</button>
    </form>
  </section>
</div>

<section class="card">
  <header class="card-head"><h2>Recent matches</h2></header>
  <?php if (!$matches): ?><div class="empty"><p class="muted">No matches yet.</p></div><?php else: ?>
  <div class="table-wrap"><table class="table">
    <thead><tr><th>Match</th><th>Date</th><th>Kills</th><th>Rank</th><th class="right">Won</th></tr></thead>
    <tbody>
    <?php foreach ($matches as $m): ?>
      <tr><td><a href="<?= e(url('/matches/' . $m['matchid'])) ?>">#<?= (int) $m['matchid'] ?></a> <?= e($m['type']) ?> · <?= e($m['map']) ?></td><td><?= fmt_dt($m['matchschedule']) ?></td><td><?= (int) $m['kills'] ?></td><td><?= $m['rank'] !== null ? '#' . (int) $m['rank'] : '—' ?></td><td class="right"><?= e(money($m['wonamount'])) ?></td></tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?php endif; ?>
</section>

<section class="card">
  <header class="card-head"><h2>Wallet history</h2><a class="btn btn-sm" href="<?= e(url('/transactions', ['q' => $p['userid']])) ?>">All transactions</a></header>
  <?php if (!$transactions): ?><div class="empty"><p class="muted">No transactions.</p></div><?php else: ?>
  <div class="table-wrap"><table class="table">
    <thead><tr><th>#</th><th>Remark</th><th>Date</th><th class="right">Amount</th></tr></thead>
    <tbody>
    <?php foreach ($transactions as $t): ?>
      <tr><td><?= (int) $t['trnid'] ?></td><td><?= e($t['status']) ?><?= $t['paytmnumber'] ? ' <small class="muted">· ' . e($t['paytmnumber']) . '</small>' : '' ?></td><td><?= fmt_dt($t['log_entdate']) ?></td><td class="right <?= (int) $t['amount'] >= 0 ? 'pos' : 'neg' ?>"><?= (int) $t['amount'] >= 0 ? '+' : '' ?><?= e(money($t['amount'])) ?></td></tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?php endif; ?>
</section>

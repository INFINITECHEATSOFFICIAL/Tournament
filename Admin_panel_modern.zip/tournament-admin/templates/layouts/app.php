<?php
$active = $active ?? '';
$admin = \App\Core\Auth::user();
$appName = env('APP_NAME', 'BattleWorld Admin');
$nav = [
    ['dashboard', '/', 'dashboard', 'Dashboard'],
    ['matches', '/matches', 'trophy', 'Matches'],
    ['scores', '/scores', 'target', 'Score updates'],
    ['players', '/players', 'users', 'Players'],
    ['transactions', '/transactions', 'wallet', 'Transactions'],
    ['withdrawals', '/withdrawals', 'cash', 'Withdrawals'],
    ['rules', '/rules', 'book', 'Rules'],
    ['media', '/media', 'image', 'Media'],
    ['settings', '/settings', 'cog', 'Settings'],
];
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex, nofollow">
  <meta name="color-scheme" content="light dark">
  <title><?= e($title ?? 'Admin') ?> · <?= e($appName) ?></title>
  <script src="<?= e(asset('js/theme.js')) ?>"></script>
  <link rel="stylesheet" href="<?= e(asset('css/app.css')) ?>">
  <script src="<?= e(asset('js/app.js')) ?>" defer></script>
</head>
<body>
<?= partial('partials/sprite') ?>
<div class="shell">
  <aside class="sidebar" id="sidebar">
    <a class="brand" href="<?= e(url('/')) ?>"><span class="brand-mark"><?= icon('trophy') ?></span><span><?= e($appName) ?></span></a>
    <nav class="nav" aria-label="Main">
      <?php foreach ($nav as [$key, $path, $ic, $label]): ?>
        <a class="nav-link<?= nav_active($active, $key) ?>" href="<?= e(url($path)) ?>"><?= icon($ic) ?><span><?= e($label) ?></span></a>
      <?php endforeach; ?>
    </nav>
    <div class="sidebar-foot">
      <?php if ($admin): ?><div class="who"><span class="avatar"><?= e(mb_strtoupper(mb_substr($admin['display_name'], 0, 1))) ?></span><span><?= e($admin['display_name']) ?><small>@<?= e($admin['username']) ?></small></span></div><?php endif; ?>
      <form method="post" action="<?= e(url('/logout')) ?>"><?= csrf_field() ?><button class="nav-link nav-button" type="submit"><?= icon('logout') ?><span>Sign out</span></button></form>
    </div>
  </aside>
  <div class="scrim" data-nav-close></div>

  <div class="main">
    <header class="topbar">
      <button class="icon-btn menu-btn" type="button" data-nav-toggle aria-label="Open menu"><?= icon('menu') ?></button>
      <h1 class="page-title"><?= e($title ?? '') ?></h1>
      <button class="icon-btn" type="button" data-theme-toggle aria-label="Toggle dark mode"><?= icon('moon') ?></button>
    </header>
    <main class="content">
      <?= partial('partials/flash') ?>
      <?= $content ?>
    </main>
  </div>
</div>
</body>
</html>

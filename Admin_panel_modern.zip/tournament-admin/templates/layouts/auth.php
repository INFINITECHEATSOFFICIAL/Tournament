<?php $appName = env('APP_NAME', 'BattleWorld Admin'); ?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex, nofollow">
  <meta name="color-scheme" content="light dark">
  <title><?= e($title ?? 'Sign in') ?> · <?= e($appName) ?></title>
  <script src="<?= e(asset('js/theme.js')) ?>"></script>
  <link rel="stylesheet" href="<?= e(asset('css/app.css')) ?>">
</head>
<body class="auth-body">
<?= partial('partials/sprite') ?>
<main class="auth-card">
  <div class="brand brand-center"><span class="brand-mark"><?= icon('trophy') ?></span><span><?= e($appName) ?></span></div>
  <?= partial('partials/flash') ?>
  <?= $content ?>
</main>
</body>
</html>

<?php
/** @var \App\Core\Paginator $pager */
if ($pager->pages <= 1) { return; }
$query = $_GET;
$link = static function (int $page) use ($query): string {
    $query['page'] = $page;
    return url(\App\Core\Request::capture()->path, $query);
};
$from = max(1, $pager->page - 2);
$to = min($pager->pages, $pager->page + 2);
?>
<nav class="pagination" aria-label="Pagination">
  <span class="muted"><?= number_format($pager->total) ?> results · page <?= $pager->page ?> of <?= $pager->pages ?></span>
  <div class="pagination-links">
    <?php if ($pager->page > 1): ?><a class="btn btn-sm" href="<?= e($link($pager->page - 1)) ?>">‹ Prev</a><?php endif; ?>
    <?php if ($from > 1): ?><a class="btn btn-sm" href="<?= e($link(1)) ?>">1</a><?php if ($from > 2): ?><span class="muted">…</span><?php endif; endif; ?>
    <?php for ($p = $from; $p <= $to; $p++): ?>
      <a class="btn btn-sm<?= $p === $pager->page ? ' btn-primary' : '' ?>" href="<?= e($link($p)) ?>"><?= $p ?></a>
    <?php endfor; ?>
    <?php if ($to < $pager->pages): ?><?php if ($to < $pager->pages - 1): ?><span class="muted">…</span><?php endif; ?><a class="btn btn-sm" href="<?= e($link($pager->pages)) ?>"><?= $pager->pages ?></a><?php endif; ?>
    <?php if ($pager->page < $pager->pages): ?><a class="btn btn-sm" href="<?= e($link($pager->page + 1)) ?>">Next ›</a><?php endif; ?>
  </div>
</nav>

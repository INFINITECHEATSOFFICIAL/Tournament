<?php foreach (\App\Core\Session::pullFlash() as $f):
    $tone = match ($f['type']) { 'success' => 'success', 'error' => 'danger', 'warning' => 'warn', default => 'info' }; ?>
  <div class="flash flash-<?= e($tone) ?>" role="status">
    <span><?= e($f['message']) ?></span>
    <button type="button" class="flash-close" data-dismiss aria-label="Dismiss"><?= icon('x') ?></button>
  </div>
<?php endforeach; ?>
